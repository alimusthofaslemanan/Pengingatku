package id.pengingatku.app.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.LocalSize
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import id.pengingatku.app.data.PhotoStorage
import id.pengingatku.app.data.ReminderStore
import id.pengingatku.app.domain.NextOccurrence
import id.pengingatku.app.domain.countdownText
import id.pengingatku.app.domain.idShort
import id.pengingatku.app.model.Reminder
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit

// ---------------- Daftar (3-5 peristiwa terdekat) ----------------

private val LIST_SHORT = DpSize(180.dp, 100.dp)
private val LIST_TALL = DpSize(180.dp, 180.dp)

class ListWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Responsive(setOf(LIST_SHORT, LIST_TALL))

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val now = LocalDateTime.now()
        val items = upcomingList(context, now)
        provideContent { ListBody(context, items, now, LocalSize.current) }
    }
}

@Composable
private fun ListBody(
    context: Context,
    items: List<Pair<Reminder, LocalDateTime>>,
    now: LocalDateTime,
    size: DpSize
) {
    val tall = size.height >= 180.dp
    val shown = items.take(if (tall) 4 else 2)
    Column(
        GlanceModifier.fillMaxSize().background(Glass.Panel).cornerRadius(28.dp).padding(10.dp)
            .clickable(openAction(context, null))
    ) {
        if (tall) {
            Text(
                "🔔 Pengingatku",
                style = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Glass.Soft)
            )
            Spacer(GlanceModifier.height(6.dp))
        }
        if (shown.isEmpty()) {
            Text("Belum ada pengingat", style = TextStyle(color = Glass.White))
        }
        shown.forEach { (r, next) ->
            Row(
                GlanceModifier.fillMaxWidth().background(Glass.tint(r.colorArgb, 0.55f))
                    .cornerRadius(16.dp).padding(horizontal = 10.dp, vertical = 6.dp)
                    .clickable(openAction(context, r)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(r.category.emoji, style = TextStyle(fontSize = 18.sp))
                Spacer(GlanceModifier.width(8.dp))
                Column(GlanceModifier.defaultWeight()) {
                    Text(
                        r.title, maxLines = 1,
                        style = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Glass.White)
                    )
                    Text(
                        next.toLocalDate().idShort(),
                        style = TextStyle(fontSize = 11.sp, color = Glass.Soft)
                    )
                }
                Text(
                    countdownText(next, now),
                    style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Glass.White)
                )
            }
            Spacer(GlanceModifier.height(5.dp))
        }
    }
}

// ---------------- Countdown (angka besar) ----------------

class CountdownWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val now = LocalDateTime.now()
        val item = upcomingList(context, now).firstOrNull()
        provideContent { CountdownBody(context, item, now) }
    }
}

@Composable
internal fun CountdownBody(context: Context, item: Pair<Reminder, LocalDateTime?>?, now: LocalDateTime) {
    if (item == null) {
        EventBody(context, null, now, DpSize(100.dp, 100.dp), null)
        return
    }
    val (r, next) = item
    val days = if (next == null) -1L else ChronoUnit.DAYS.between(now.toLocalDate(), next.toLocalDate())
    val big = when {
        next == null -> "Lewat"
        days >= 2L -> "$days"
        days == 1L -> "Besok"
        else -> countdownText(next, now).removeSuffix(" lagi").removeSuffix(" ❤️")
    }
    val bigSize = if (days >= 2L) 46.sp else 24.sp
    Column(
        GlanceModifier.fillMaxSize().background(Glass.tint(r.colorArgb, 0.82f)).cornerRadius(28.dp)
            .padding(10.dp).clickable(openAction(context, r)),
        verticalAlignment = Alignment.CenterVertically,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "MENUJU ${r.title.uppercase()}", maxLines = 2,
            style = TextStyle(
                fontSize = 11.sp, fontWeight = FontWeight.Bold,
                color = Glass.Soft, textAlign = TextAlign.Center
            )
        )
        Text(
            big,
            style = TextStyle(
                fontSize = bigSize, fontWeight = FontWeight.Bold,
                color = Glass.White, textAlign = TextAlign.Center
            )
        )
        if (days >= 2L) {
            Text("HARI", style = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Glass.White))
        }
        Text(
            (next?.toLocalDate() ?: r.date).idShort(),
            style = TextStyle(fontSize = 11.sp, color = Glass.Soft)
        )
    }
}

// ---------------- Event Tertentu (dipilih saat widget ditambahkan) ----------------

object WidgetPrefs {
    private fun p(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("pengingatku_widgets", Context.MODE_PRIVATE)

    fun get(ctx: Context, appWidgetId: Int): Long = p(ctx).getLong("w$appWidgetId", -1L)
    fun set(ctx: Context, appWidgetId: Int, reminderId: Long) {
        p(ctx).edit().putLong("w$appWidgetId", reminderId).apply()
    }
}

private val SP_SMALL = DpSize(100.dp, 100.dp)
private val SP_MEDIUM = DpSize(220.dp, 100.dp)
private val SP_LARGE = DpSize(220.dp, 200.dp)

class SpecificWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Responsive(setOf(SP_SMALL, SP_MEDIUM, SP_LARGE))

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val now = LocalDateTime.now()
        val appWidgetId = GlanceAppWidgetManager(context).getAppWidgetId(id)
        val rid = WidgetPrefs.get(context, appWidgetId)
        val r = ReminderStore.load(context).find { it.id == rid }
        val item: Pair<Reminder, LocalDateTime?>? = r?.let { it to NextOccurrence.of(it, now) }
        val photo = r?.photo?.let { PhotoStorage.loadScaled(context, it, 360) }
        provideContent {
            EventBody(context, item, now, LocalSize.current, photo, "Pengingat tidak ditemukan")
        }
    }
}
