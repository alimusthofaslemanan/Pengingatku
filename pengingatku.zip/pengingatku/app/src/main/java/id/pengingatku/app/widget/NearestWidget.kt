package id.pengingatku.app.widget

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.LocalSize
import androidx.glance.action.Action
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.ContentScale
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import id.pengingatku.app.EXTRA_REMINDER_ID
import id.pengingatku.app.MainActivity
import id.pengingatku.app.data.PhotoStorage
import id.pengingatku.app.data.ReminderStore
import id.pengingatku.app.domain.NextOccurrence
import id.pengingatku.app.domain.countdownText
import id.pengingatku.app.domain.idLong
import id.pengingatku.app.domain.idShort
import id.pengingatku.app.model.Reminder
import id.pengingatku.app.model.categoryLabel
import id.pengingatku.app.model.emoji
import id.pengingatku.app.model.recurrenceText
import java.time.LocalDateTime

/** Palet "kaca": warna tema semi transparan dengan teks putih. */
internal object Glass {
    val White = ColorProvider(Color.White)
    val Soft = ColorProvider(Color(0xE6FFFFFF))
    val ChipBg = ColorProvider(Color(0x47FFFFFF))
    val RowBg = ColorProvider(Color(0x33FFFFFF))
    val Panel = ColorProvider(Color(0xCC0F4F3C))
    fun tint(argb: Long, alpha: Float = 0.80f) = ColorProvider(Color(argb).copy(alpha = alpha))
}

internal fun upcomingList(ctx: Context, now: LocalDateTime): List<Pair<Reminder, LocalDateTime>> =
    ReminderStore.load(ctx)
        .mapNotNull { r -> NextOccurrence.of(r, now)?.let { r to it } }
        .sortedBy { it.second }

internal fun openAction(context: Context, r: Reminder?): Action {
    val intent = Intent(context, MainActivity::class.java)
    if (r != null) {
        intent.apply {
            data = Uri.parse("pengingatku://reminder/${r.id}")
            putExtra(EXTRA_REMINDER_ID, r.id)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
    }
    return actionStartActivity(intent)
}

private val SMALL = DpSize(100.dp, 100.dp)
private val MEDIUM = DpSize(220.dp, 100.dp)
private val LARGE = DpSize(220.dp, 200.dp)

class NearestWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Responsive(setOf(SMALL, MEDIUM, LARGE))

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val now = LocalDateTime.now()
        val item = upcomingList(context, now).firstOrNull()
        val photo = item?.first?.photo?.let { PhotoStorage.loadScaled(context, it, 360) }
        provideContent { EventBody(context, item, now, LocalSize.current, photo) }
    }
}

@Composable
internal fun EventBody(
    context: Context,
    item: Pair<Reminder, LocalDateTime?>?,
    now: LocalDateTime,
    size: DpSize,
    photo: Bitmap?,
    emptyText: String = "Belum ada pengingat"
) {
    if (item == null) {
        Box(
            GlanceModifier.fillMaxSize().background(Glass.Panel).cornerRadius(28.dp)
                .padding(16.dp).clickable(openAction(context, null)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                emptyText,
                style = TextStyle(color = Glass.White, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            )
        }
        return
    }

    val (r, next) = item
    val shownDate = next?.toLocalDate() ?: r.date
    val base = GlanceModifier.fillMaxSize().background(Glass.tint(r.colorArgb)).cornerRadius(28.dp)
    val open = openAction(context, r)
    val count = countdownText(next, now)

    when {
        size.height >= 200.dp -> Column(base.clickable(open)) {
            WidgetCover(photo, r.emoji, 44.sp, GlanceModifier.fillMaxWidth().height(80.dp))
            Column(GlanceModifier.fillMaxWidth().padding(14.dp)) {
                Text(
                    r.title, maxLines = 2,
                    style = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Glass.White)
                )
                Text(shownDate.idLong(), style = TextStyle(fontSize = 13.sp, color = Glass.Soft))
                Spacer(GlanceModifier.height(8.dp))
                Chip(count)
                if (r.description.isNotBlank()) {
                    Spacer(GlanceModifier.height(8.dp))
                    Text(
                        "\"${r.description}\"", maxLines = 3,
                        style = TextStyle(fontSize = 13.sp, color = Glass.White)
                    )
                }
                Spacer(GlanceModifier.height(6.dp))
                Text(
                    "${r.emoji} ${r.categoryLabel} · ${recurrenceText(r)}",
                    style = TextStyle(fontSize = 12.sp, color = Glass.Soft)
                )
            }
        }

        size.width >= 220.dp -> Row(base.clickable(open), verticalAlignment = Alignment.CenterVertically) {
            WidgetCover(photo, r.emoji, 38.sp, GlanceModifier.width(88.dp).fillMaxHeight())
            Column(GlanceModifier.defaultWeight().padding(12.dp)) {
                Text(
                    r.title, maxLines = 2,
                    style = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Glass.White)
                )
                Text(shownDate.idShort(), style = TextStyle(fontSize = 12.sp, color = Glass.Soft))
                Spacer(GlanceModifier.height(6.dp))
                Chip(count)
            }
        }

        else -> Column(
            base.clickable(open).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(r.emoji, style = TextStyle(fontSize = 26.sp))
            Text(
                r.title, maxLines = 2,
                style = TextStyle(
                    fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    color = Glass.White, textAlign = TextAlign.Center
                )
            )
            Spacer(GlanceModifier.height(4.dp))
            Chip(count)
        }
    }
}

@Composable
internal fun Chip(text: String) {
    Box(
        GlanceModifier.background(Glass.ChipBg).cornerRadius(14.dp)
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(
            "⏱ $text",
            style = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Glass.White)
        )
    }
}

@Composable
private fun WidgetCover(photo: Bitmap?, emoji: String, fontSize: TextUnit, modifier: GlanceModifier) {
    if (photo != null) {
        Image(ImageProvider(photo), null, modifier, contentScale = ContentScale.Crop)
    } else {
        Box(modifier.background(Glass.ChipBg), contentAlignment = Alignment.Center) {
            Text(emoji, style = TextStyle(fontSize = fontSize))
        }
    }
}
