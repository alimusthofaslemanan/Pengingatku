package id.pengingatku.app.widget

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.graphics.Bitmap
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.TextUnit
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.layout.ContentScale
import id.pengingatku.app.data.PhotoStorage
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.LocalSize
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import id.pengingatku.app.EXTRA_REMINDER_ID
import id.pengingatku.app.MainActivity
import id.pengingatku.app.data.ReminderStore
import id.pengingatku.app.domain.NextOccurrence
import id.pengingatku.app.domain.countdownText
import id.pengingatku.app.domain.idLong
import id.pengingatku.app.domain.idShort
import id.pengingatku.app.model.Reminder
import java.time.LocalDateTime

private val SMALL = DpSize(100.dp, 100.dp)
private val MEDIUM = DpSize(220.dp, 100.dp)
private val LARGE = DpSize(220.dp, 200.dp)

class NearestWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Responsive(setOf(SMALL, MEDIUM, LARGE))

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val now = LocalDateTime.now()
        val nearest = ReminderStore.load(context)
            .mapNotNull { r -> NextOccurrence.of(r, now)?.let { r to it } }
            .minByOrNull { it.second }

        val photo = nearest?.first?.photo?.let { PhotoStorage.loadScaled(context, it, 360) }

        provideContent {
            GlanceTheme {
                WidgetBody(context, nearest, now, LocalSize.current, photo)
            }
        }
    }
}

@Composable
private fun WidgetBody(
    context: Context,
    item: Pair<Reminder, LocalDateTime>?,
    now: LocalDateTime,
    size: DpSize,
    photo: Bitmap?
) {
    val base = GlanceModifier.fillMaxSize()
        .background(GlanceTheme.colors.widgetBackground)
        .cornerRadius(24.dp)

    if (item == null) {
        Box(
            base.padding(16.dp).clickable(
                actionStartActivity(Intent(context, MainActivity::class.java))
            ),
            contentAlignment = Alignment.Center
        ) {
            Text("Belum ada pengingat", style = TextStyle(color = GlanceTheme.colors.onSurface))
        }
        return
    }

    val (r, next) = item
    val open = actionStartActivity(
        Intent(context, MainActivity::class.java).apply {
            data = Uri.parse("pengingatku://reminder/${r.id}")
            putExtra(EXTRA_REMINDER_ID, r.id)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
    )
    val cover = ColorProvider(Color(r.colorArgb))
    val count = countdownText(next, now)
    val onSurface = GlanceTheme.colors.onSurface
    val muted = GlanceTheme.colors.onSurfaceVariant

    when {
        size.height >= 200.dp -> Column(base.clickable(open)) {
            WidgetCover(photo, cover, r.category.emoji, 44.sp, GlanceModifier.fillMaxWidth().height(80.dp))
            Column(GlanceModifier.fillMaxWidth().padding(14.dp)) {
                Text(
                    r.title, maxLines = 2,
                    style = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Bold, color = onSurface)
                )
                Text(next.toLocalDate().idLong(), style = TextStyle(fontSize = 13.sp, color = muted))
                Spacer(GlanceModifier.height(8.dp))
                Chip(count)
                if (r.description.isNotBlank()) {
                    Spacer(GlanceModifier.height(8.dp))
                    Text(
                        "\"${r.description}\"", maxLines = 3,
                        style = TextStyle(fontSize = 13.sp, color = onSurface)
                    )
                }
                Spacer(GlanceModifier.height(6.dp))
                Text(
                    "${r.category.emoji} ${r.category.label} · ${r.recurrence.label}",
                    style = TextStyle(fontSize = 12.sp, color = muted)
                )
            }
        }

        size.width >= 220.dp -> Row(
            base.clickable(open), verticalAlignment = Alignment.CenterVertically
        ) {
            WidgetCover(photo, cover, r.category.emoji, 38.sp, GlanceModifier.width(88.dp).fillMaxHeight())
            Column(GlanceModifier.defaultWeight().padding(12.dp)) {
                Text(
                    r.title, maxLines = 2,
                    style = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Bold, color = onSurface)
                )
                Text(next.toLocalDate().idShort(), style = TextStyle(fontSize = 12.sp, color = muted))
                Spacer(GlanceModifier.height(6.dp))
                Chip(count)
            }
        }

        else -> Column(
            base.clickable(open).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(r.category.emoji, style = TextStyle(fontSize = 26.sp))
            Text(
                r.title, maxLines = 2,
                style = TextStyle(
                    fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    color = onSurface, textAlign = TextAlign.Center
                )
            )
            Spacer(GlanceModifier.height(4.dp))
            Text(
                count,
                style = TextStyle(
                    fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    color = GlanceTheme.colors.primary, textAlign = TextAlign.Center
                )
            )
        }
    }
}

@Composable
private fun Chip(text: String) {
    Box(
        GlanceModifier.background(GlanceTheme.colors.primaryContainer)
            .cornerRadius(14.dp)
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(
            "⏱ $text",
            style = TextStyle(
                fontSize = 14.sp, fontWeight = FontWeight.Bold,
                color = GlanceTheme.colors.onPrimaryContainer
            )
        )
    }
}

@Composable
private fun WidgetCover(
    photo: Bitmap?, color: ColorProvider, emoji: String, fontSize: TextUnit, modifier: GlanceModifier
) {
    if (photo != null) {
        Image(ImageProvider(photo), null, modifier, contentScale = ContentScale.Crop)
    } else {
        Box(modifier.background(color), contentAlignment = Alignment.Center) {
            Text(emoji, style = TextStyle(fontSize = fontSize))
        }
    }
}
