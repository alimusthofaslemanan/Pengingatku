package id.pengingatku.app.widget

import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.glance.appwidget.GlanceAppWidgetManager
import id.pengingatku.app.data.ReminderStore
import id.pengingatku.app.domain.NextOccurrence
import id.pengingatku.app.ui.ReminderRow
import id.pengingatku.app.ui.appBrush
import id.pengingatku.app.ui.theme.PengingatkuTheme
import kotlinx.coroutines.launch
import java.time.LocalDateTime

/** Layar pilihan pengingat saat widget "Event Tertentu" ditambahkan ke Home Screen. */
class WidgetConfigActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val appWidgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        setResult(RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId))
        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }

        val list = ReminderStore.load(this)
        val now = LocalDateTime.now()
        setContent {
            PengingatkuTheme(isSystemInDarkTheme(), false) {
                val scope = rememberCoroutineScope()
                Surface(
                    Modifier.fillMaxSize().background(appBrush()),
                    color = Color.Transparent,
                    contentColor = MaterialTheme.colorScheme.onBackground
                ) {
                    Column(Modifier.systemBarsPadding().padding(20.dp)) {
                        Text(
                            "Pilih pengingat untuk widget",
                            style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(12.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(list, key = { it.id }) { r ->
                                ReminderRow(r, NextOccurrence.of(r, now), now) {
                                    scope.launch {
                                        WidgetPrefs.set(this@WidgetConfigActivity, appWidgetId, r.id)
                                        val gid = GlanceAppWidgetManager(this@WidgetConfigActivity)
                                            .getGlanceIdBy(appWidgetId)
                                        SpecificWidget().update(this@WidgetConfigActivity, gid)
                                        setResult(
                                            RESULT_OK,
                                            Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
                                        )
                                        finish()
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
