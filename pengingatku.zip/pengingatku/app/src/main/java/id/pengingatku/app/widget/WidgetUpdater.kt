package id.pengingatku.app.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.updateAll
import id.pengingatku.app.data.ReminderStore
import id.pengingatku.app.domain.NextOccurrence
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.temporal.ChronoUnit

object WidgetUpdater {
    const val ACTION_TICK = "id.pengingatku.app.TICK"

    suspend fun updateAll(ctx: Context) {
        NearestWidget().updateAll(ctx)
        scheduleNext(ctx)
    }

    fun refreshAsync(ctx: Context) {
        val app = ctx.applicationContext
        CoroutineScope(Dispatchers.Default).launch { updateAll(app) }
    }

    /** Alarm berikutnya: awal jam berikutnya, atau saat peristiwa terdekat tiba (mana lebih dulu). */
    fun scheduleNext(ctx: Context) {
        val now = LocalDateTime.now()
        var trigger = now.truncatedTo(ChronoUnit.HOURS).plusHours(1)
        val nearest = ReminderStore.load(ctx).mapNotNull { NextOccurrence.of(it, now) }.minOrNull()
        if (nearest != null && nearest.isBefore(trigger)) trigger = nearest.plusSeconds(1)

        val ms = trigger.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            ctx, 0,
            Intent(ctx, RefreshReceiver::class.java).setAction(ACTION_TICK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
    }
}

/** Menangani alarm, reboot, perubahan tanggal/jam/zona waktu, dan pembaruan aplikasi. */
class RefreshReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                WidgetUpdater.updateAll(context.applicationContext)
            } finally {
                pending.finish()
            }
        }
    }
}

class NearestWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = NearestWidget()

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        super.onUpdate(context, appWidgetManager, appWidgetIds)
        WidgetUpdater.scheduleNext(context)
    }
}
