package id.pengingatku.app.ui.theme

import android.os.Build
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val Light = lightColorScheme(
    primary = Color(0xFF0F6B4F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD7F0E3),
    onPrimaryContainer = Color(0xFF00382A),
    background = Color(0xFFFFFBF7),
    surface = Color.White,
    surfaceVariant = Color(0xFFF3EEE8)
)

private val Dark = darkColorScheme(
    primary = Color(0xFF6FD3A8),
    onPrimary = Color(0xFF00382A),
    primaryContainer = Color(0xFF14503C),
    onPrimaryContainer = Color(0xFFD7F0E3),
    background = Color(0xFF0E1512),
    surface = Color(0xFF17201C),
    surfaceVariant = Color(0xFF222C27)
)

@Composable
fun PengingatkuTheme(dark: Boolean, dynamic: Boolean, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val scheme = when {
        dynamic && Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> Dark
        else -> Light
    }
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(20.dp),
            large = RoundedCornerShape(28.dp)
        ),
        content = content
    )
}
