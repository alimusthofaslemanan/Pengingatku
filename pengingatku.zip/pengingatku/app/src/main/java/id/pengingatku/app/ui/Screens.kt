package id.pengingatku.app.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.pengingatku.app.domain.MONTHS
import id.pengingatku.app.domain.NextOccurrence
import id.pengingatku.app.model.Category
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.YearMonth

private fun listPadding(p: PaddingValues) = PaddingValues(
    start = 20.dp, end = 20.dp,
    top = p.calculateTopPadding() + 12.dp,
    bottom = p.calculateBottomPadding() + 96.dp
)

@Composable
fun HomeScreen(state: AppState, now: LocalDateTime, pad: PaddingValues, onOpen: (Long) -> Unit) {
    val up = state.upcoming(now)
    LazyColumn(
        contentPadding = listPadding(pad),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text("Pengingatku", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Jangan sampai lupa momen penting.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (up.isEmpty()) {
            item { Text("Belum ada pengingat. Ketuk + untuk menambah.") }
        } else {
            item { SectionTitle("Peristiwa Terdekat") }
            item { HeroCard(up[0].first, up[0].second, now) { onOpen(up[0].first.id) } }
            item { SectionTitle("Semua Pengingat") }
            items(up, key = { it.first.id }) { (r, n) -> ReminderRow(r, n, now) { onOpen(r.id) } }
        }
    }
}

@Composable
fun CalendarScreen(state: AppState, now: LocalDateTime, pad: PaddingValues, onOpen: (Long) -> Unit) {
    var ym by remember { mutableStateOf(YearMonth.from(now)) }
    var selected by remember { mutableStateOf(now.toLocalDate()) }
    val offset = ym.atDay(1).dayOfWeek.value - 1
    val rows = (offset + ym.lengthOfMonth() + 6) / 7
    val day = state.reminders.filter { NextOccurrence.occursOn(it, selected) }

    LazyColumn(contentPadding = listPadding(pad), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("Kalender", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { ym = ym.minusMonths(1) }) { Text("‹", fontSize = 22.sp) }
                Text(
                    "${MONTHS[ym.monthValue - 1]} ${ym.year}", Modifier.weight(1f),
                    textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold
                )
                TextButton(onClick = { ym = ym.plusMonths(1) }) { Text("›", fontSize = 22.sp) }
            }
        }
        item {
            Row(Modifier.fillMaxWidth()) {
                listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min").forEach {
                    Text(it, Modifier.weight(1f), textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        items(rows) { row ->
            Row(Modifier.fillMaxWidth()) {
                for (col in 0 until 7) {
                    val dayNum = row * 7 + col - offset + 1
                    Box(Modifier.weight(1f).height(44.dp), contentAlignment = Alignment.Center) {
                        if (dayNum in 1..ym.lengthOfMonth()) {
                            val d = ym.atDay(dayNum)
                            val isSel = d == selected
                            val has = state.reminders.any { NextOccurrence.occursOn(it, d) && it.recurrence.name != "DAILY" }
                            Box(
                                Modifier.size(38.dp).clip(CircleShape)
                                    .background(if (isSel) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.Transparent)
                                    .clickable { selected = d },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        "$dayNum", style = MaterialTheme.typography.bodyMedium,
                                        color = if (isSel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                    )
                                    if (has) Box(
                                        Modifier.size(5.dp).clip(CircleShape).background(
                                            if (isSel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        item { SectionTitle("Pengingat ${selected.dayOfMonth} ${MONTHS[selected.monthValue - 1]}") }
        if (day.isEmpty()) item { Text("Tidak ada pengingat.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(day, key = { it.id }) { r ->
            ReminderRow(r, NextOccurrence.of(r, now), now) { onOpen(r.id) }
        }
    }
}

@Composable
fun RemindersScreen(state: AppState, now: LocalDateTime, pad: PaddingValues, onOpen: (Long) -> Unit) {
    var query by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf<Category?>(null) }
    val list = state.reminders
        .filter { (cat == null || it.category == cat) && it.title.contains(query, ignoreCase = true) }
        .map { it to NextOccurrence.of(it, now) }
        .sortedWith(compareBy({ it.second == null }, { it.second }))

    LazyColumn(contentPadding = listPadding(pad), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Pengingat", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("🔍 Cari pengingat") },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(cat == null, { cat = null }, label = { Text("Semua") }) }
                items(Category.values().toList()) { c ->
                    FilterChip(cat == c, { cat = if (cat == c) null else c },
                        label = { Text("${c.emoji} ${c.label}") })
                }
            }
        }
        items(list, key = { it.first.id }) { (r, n) -> ReminderRow(r, n, now) { onOpen(r.id) } }
    }
}

@Composable
fun SettingsScreen(state: AppState, pad: PaddingValues) {
    LazyColumn(contentPadding = listPadding(pad), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Pengaturan", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionTitle("Tema")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(ThemeMode.SYSTEM to "Sistem", ThemeMode.LIGHT to "Terang", ThemeMode.DARK to "Gelap").forEach { (m, l) ->
                        FilterChip(state.themeMode == m, { state.themeMode = m }, label = { Text(l) })
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Warna dinamis", fontWeight = FontWeight.SemiBold)
                    Text("Ikuti wallpaper (Android 12+)", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(state.dynamicColor, { state.dynamicColor = it })
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Text(
                    "Segera hadir: backup & restore JSON, notifikasi, dan widget Home Screen.",
                    Modifier.padding(16.dp)
                )
            }
        }
    }
}
