package id.pengingatku.app.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import id.pengingatku.app.data.PhotoStorage
import id.pengingatku.app.data.ReminderStore
import id.pengingatku.app.model.Reminder
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.pengingatku.app.domain.MONTHS
import id.pengingatku.app.domain.NextOccurrence
import id.pengingatku.app.model.Category
import id.pengingatku.app.model.categoryKey
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.YearMonth

private fun listPadding(p: PaddingValues) = PaddingValues(
    start = 20.dp, end = 20.dp,
    top = p.calculateTopPadding() + 12.dp,
    bottom = p.calculateBottomPadding() + 96.dp
)

@Composable
fun HomeScreen(state: AppState, now: LocalDateTime, pad: PaddingValues, onOpen: (Long) -> Unit) {
    val up = state.upcoming(now)
    LazyColumn(
        contentPadding = listPadding(pad),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Banner()
        }
        if (up.isEmpty()) {
            item { Text("Belum ada pengingat. Ketuk + untuk menambah.") }
        } else {
            item { SectionTitle("Peristiwa Terdekat") }
            item { HeroCard(up[0].first, up[0].second, now) { onOpen(up[0].first.id) } }
            item { SectionTitle("Semua Pengingat") }
            items(up, key = { it.first.id }) { (r, n) -> ReminderRow(r, n, now) { onOpen(r.id) } }
        }
    }
}

@Composable
fun CalendarScreen(state: AppState, now: LocalDateTime, pad: PaddingValues, onOpen: (Long) -> Unit) {
    var ym by remember { mutableStateOf(YearMonth.from(now)) }
    var selected by remember { mutableStateOf(now.toLocalDate()) }
    val offset = ym.atDay(1).dayOfWeek.value - 1
    val rows = (offset + ym.lengthOfMonth() + 6) / 7
    val day = state.reminders.filter { NextOccurrence.occursOn(it, selected) }

    LazyColumn(contentPadding = listPadding(pad), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("Kalender", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { ym = ym.minusMonths(1) }) { Text("‹", fontSize = 22.sp) }
                Text(
                    "${MONTHS[ym.monthValue - 1]} ${ym.year}", Modifier.weight(1f),
                    textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold
                )
                TextButton(onClick = { ym = ym.plusMonths(1) }) { Text("›", fontSize = 22.sp) }
            }
        }
        item {
            Row(Modifier.fillMaxWidth()) {
                listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min").forEach {
                    Text(it, Modifier.weight(1f), textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        items(rows) { row ->
            Row(Modifier.fillMaxWidth()) {
                for (col in 0 until 7) {
                    val dayNum = row * 7 + col - offset + 1
                    Box(Modifier.weight(1f).height(44.dp), contentAlignment = Alignment.Center) {
                        if (dayNum in 1..ym.lengthOfMonth()) {
                            val d = ym.atDay(dayNum)
                            val isSel = d == selected
                            val has = state.reminders.any { NextOccurrence.occursOn(it, d) && it.recurrence.name != "DAILY" }
                            Box(
                                Modifier.size(38.dp).clip(CircleShape)
                                    .background(if (isSel) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.Transparent)
                                    .clickable { selected = d },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        "$dayNum", style = MaterialTheme.typography.bodyMedium,
                                        color = if (isSel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                    )
                                    if (has) Box(
                                        Modifier.size(5.dp).clip(CircleShape).background(
                                            if (isSel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        item { SectionTitle("Pengingat ${selected.dayOfMonth} ${MONTHS[selected.monthValue - 1]}") }
        if (day.isEmpty()) item { Text("Tidak ada pengingat.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(day, key = { it.id }) { r ->
            ReminderRow(r, NextOccurrence.of(r, now), now) { onOpen(r.id) }
        }
    }
}

private enum class SortMode(val label: String) { NEAREST("Terdekat"), NAME("Nama"), NEWEST("Terbaru") }
private typealias Item = Pair<Reminder, LocalDateTime?>

@Composable
fun RemindersScreen(state: AppState, now: LocalDateTime, pad: PaddingValues, onOpen: (Long) -> Unit) {
    var query by remember { mutableStateOf("") }
    var catKey by remember { mutableStateOf<String?>(null) }
    var sort by remember { mutableStateOf(SortMode.NEAREST) }
    var showArchive by remember { mutableStateOf(false) }

    val base: List<Item> = state.reminders
        .filter {
            it.archived == showArchive &&
                (catKey == null || it.categoryKey == catKey) &&
                it.title.contains(query, ignoreCase = true)
        }
        .map { it to NextOccurrence.of(it, now) }
    val list: List<Item> = when (sort) {
        SortMode.NEAREST -> base.sortedWith(
            compareBy<Item>({ !it.first.pinned }, { it.second == null }, { it.second })
        )
        SortMode.NAME -> base.sortedWith(
            compareBy<Item>({ !it.first.pinned }, { it.first.title.lowercase() })
        )
        SortMode.NEWEST -> base.sortedWith(
            compareBy<Item>({ !it.first.pinned }, { -it.first.id })
        )
    }

    LazyColumn(contentPadding = listPadding(pad), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Pengingat", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("🔍 Cari pengingat") },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(catKey == null, { catKey = null }, label = { Text("Semua") }) }
                items(Category.values().toList()) { c ->
                    FilterChip(catKey == c.name, { catKey = if (catKey == c.name) null else c.name },
                        label = { Text("${c.emoji} ${c.label}") })
                }
                items(state.customCategories) { (n, e) ->
                    FilterChip(catKey == n, { catKey = if (catKey == n) null else n },
                        label = { Text("$e $n") })
                }
            }
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(SortMode.values().toList()) { m ->
                    FilterChip(sort == m, { sort = m }, label = { Text(m.label) })
                }
                item { FilterChip(showArchive, { showArchive = !showArchive }, label = { Text("📦 Arsip") }) }
            }
        }
        if (list.isEmpty()) {
            item {
                Text(
                    if (showArchive) "Belum ada pengingat yang diarsipkan." else "Tidak ada pengingat.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        items(list, key = { it.first.id }) { (r, n) -> ReminderRow(r, n, now) { onOpen(r.id) } }
    }
}

@Composable
fun SettingsScreen(state: AppState, pad: PaddingValues) {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<List<Reminder>?>(null) }
    var newCatEmoji by remember { mutableStateOf("") }
    var newCatName by remember { mutableStateOf("") }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            val ok = runCatching {
                ctx.contentResolver.openOutputStream(uri)!!.use {
                    it.write(ReminderStore.exportJson(ctx, state.reminders.toList()).toByteArray())
                }
            }.isSuccess
            Toast.makeText(ctx, if (ok) "Backup tersimpan" else "Gagal menyimpan backup", Toast.LENGTH_SHORT).show()
        }
    }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val text = runCatching {
                ctx.contentResolver.openInputStream(uri)!!.use { String(it.readBytes()) }
            }.getOrNull()
            val list = text?.let { ReminderStore.importJson(ctx, it) }
            if (list == null) Toast.makeText(ctx, "File backup tidak valid", Toast.LENGTH_SHORT).show()
            else pending = list
        }
    }

    LazyColumn(contentPadding = listPadding(pad), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Pengaturan", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionTitle("Tema")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(ThemeMode.SYSTEM to "Sistem", ThemeMode.LIGHT to "Terang", ThemeMode.DARK to "Gelap").forEach { (m, l) ->
                        FilterChip(state.themeMode == m, { state.themeMode = m }, label = { Text(l) })
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Warna dinamis", fontWeight = FontWeight.SemiBold)
                    Text("Ikuti wallpaper (Android 12+)", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(state.dynamicColor, { state.dynamicColor = it })
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionTitle("Kategori Saya")
                if (state.customCategories.isEmpty()) {
                    Text("Belum ada kategori sendiri.", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                state.customCategories.forEach { (n, e) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("$e  $n", Modifier.weight(1f))
                        TextButton(onClick = { state.removeCategory(n) }) { Text("Hapus") }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(newCatEmoji, { newCatEmoji = it.take(4) }, label = { Text("Ikon") },
                        singleLine = true, modifier = Modifier.width(84.dp))
                    OutlinedTextField(newCatName, { newCatName = it }, label = { Text("Nama kategori") },
                        singleLine = true, modifier = Modifier.weight(1f))
                    Button(
                        onClick = { state.addCategory(newCatName, newCatEmoji); newCatName = ""; newCatEmoji = "" },
                        enabled = newCatName.isNotBlank()
                    ) { Text("＋") }
                }
            }
        }
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)
                ),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle("Backup & Restore")
                    Text(
                        "Simpan semua pengingat (termasuk foto) ke file JSON, atau pulihkan dari file backup.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { exportLauncher.launch("pengingatku-backup.json") }) { Text("Ekspor") }
                        OutlinedButton(onClick = {
                            importLauncher.launch(arrayOf("application/json", "text/*", "*/*"))
                        }) { Text("Impor") }
                    }
                }
            }
        }
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                ),
                shape = RoundedCornerShape(24.dp)
            ) {
                Text(
                    "Widget: tekan lama layar utama → Widget → Pengingatku. Tersedia Peristiwa Terdekat, Daftar, Countdown, dan Event Tertentu.",
                    Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }

    pending?.let { list ->
        AlertDialog(
            onDismissRequest = {
                list.forEach { r -> r.photo?.let { PhotoStorage.delete(ctx, it) } }
                pending = null
            },
            title = { Text("Pulihkan backup?") },
            text = { Text("Semua pengingat saat ini akan diganti dengan ${list.size} pengingat dari file backup.") },
            confirmButton = {
                TextButton(onClick = { state.replaceAll(list); pending = null }) { Text("Ganti") }
            },
            dismissButton = {
                TextButton(onClick = {
                    list.forEach { r -> r.photo?.let { PhotoStorage.delete(ctx, it) } }
                    pending = null
                }) { Text("Batal") }
            }
        )
    }
}
