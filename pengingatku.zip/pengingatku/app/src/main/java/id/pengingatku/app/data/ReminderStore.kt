package id.pengingatku.app.data

import android.content.Context
import android.util.Base64
import id.pengingatku.app.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime

/** Penyimpanan lokal (SharedPreferences + JSON), dibaca oleh aplikasi dan widget. */
object ReminderStore {
    private const val PREFS = "pengingatku"
    private const val KEY = "reminders"

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun toJson(r: Reminder) = JSONObject().apply {
        put("id", r.id)
        put("title", r.title)
        put("cat", r.category.name)
        put("date", r.date.toString())
        put("time", r.time.toString())
        put("rec", r.recurrence.name)
        put("desc", r.description)
        put("color", r.colorArgb)
        put("pinned", r.pinned)
        put("photo", r.photo ?: "")
        put("notify", r.notify.joinToString(","))
        put("interval", r.interval)
        put("wmask", r.weekdayMask)
        put("allDay", r.allDay)
        put("archived", r.archived)
        put("catName", r.catName ?: "")
        put("catEmoji", r.catEmoji ?: "")
        put("icon", r.icon ?: "")
    }

    private fun fromJson(o: JSONObject): Reminder {
        val rec = Recurrence.valueOf(o.getString("rec"))
        return Reminder(
            id = o.getLong("id"),
            title = o.getString("title"),
            category = Category.valueOf(o.getString("cat")),
            date = LocalDate.parse(o.getString("date")),
            time = LocalTime.parse(o.getString("time")),
            recurrence = rec,
            description = o.optString("desc", ""),
            colorArgb = o.getLong("color"),
            pinned = o.optBoolean("pinned", false),
            photo = o.optString("photo", "").takeIf { it.isNotBlank() },
            notify = if (o.has("notify"))
                o.optString("notify", "").split(",").mapNotNull { it.trim().toIntOrNull() }
            else defaultNotify(rec),
            interval = o.optInt("interval", 1).coerceAtLeast(1),
            weekdayMask = o.optInt("wmask", 0),
            allDay = o.optBoolean("allDay", false),
            archived = o.optBoolean("archived", false),
            catName = o.optString("catName", "").takeIf { it.isNotBlank() },
            catEmoji = o.optString("catEmoji", "").takeIf { it.isNotBlank() },
            icon = o.optString("icon", "").takeIf { it.isNotBlank() }
        )
    }

    fun load(ctx: Context): List<Reminder> {
        val raw = prefs(ctx).getString(KEY, null) ?: return DummyData.all()
        val arr = runCatching { JSONArray(raw) }.getOrNull() ?: return DummyData.all()
        return (0 until arr.length()).mapNotNull { i ->
            runCatching { fromJson(arr.getJSONObject(i)) }.getOrNull()
        }
    }

    fun save(ctx: Context, list: List<Reminder>) {
        val arr = JSONArray()
        list.forEach { arr.put(toJson(it)) }
        prefs(ctx).edit().putString(KEY, arr.toString()).apply()
    }

    fun loadTheme(ctx: Context): Pair<String, Boolean> =
        prefs(ctx).getString("theme", "SYSTEM")!! to prefs(ctx).getBoolean("dynamic", false)

    fun saveTheme(ctx: Context, mode: String, dynamic: Boolean) {
        prefs(ctx).edit().putString("theme", mode).putBoolean("dynamic", dynamic).apply()
    }

    fun loadCategories(ctx: Context): List<Pair<String, String>> {
        val raw = prefs(ctx).getString("cats", null) ?: return emptyList()
        val arr = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            runCatching { arr.getJSONObject(i).let { it.getString("n") to it.getString("e") } }.getOrNull()
        }
    }

    fun saveCategories(ctx: Context, list: List<Pair<String, String>>) {
        val arr = JSONArray()
        list.forEach { (n, e) -> arr.put(JSONObject().put("n", n).put("e", e)) }
        prefs(ctx).edit().putString("cats", arr.toString()).apply()
    }

    // ---------- Backup / restore (foto disertakan sebagai base64) ----------

    fun exportJson(ctx: Context, list: List<Reminder>): String {
        val arr = JSONArray()
        list.forEach { r ->
            val o = toJson(r)
            r.photo?.let { n ->
                PhotoStorage.readBytes(ctx, n)?.let { b ->
                    o.put("photoData", Base64.encodeToString(b, Base64.NO_WRAP))
                }
            }
            arr.put(o)
        }
        return JSONObject().put("app", "Pengingatku").put("version", 1)
            .put("reminders", arr).toString(2)
    }

    /** Mengembalikan null bila file tidak valid. Foto di file disimpan ulang sebagai file lokal baru. */
    fun importJson(ctx: Context, text: String): List<Reminder>? = runCatching {
        val arr = JSONObject(text).getJSONArray("reminders")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val r = fromJson(o)
            val data = o.optString("photoData", "")
            if (data.isNotBlank())
                r.copy(photo = PhotoStorage.saveBytes(ctx, Base64.decode(data, Base64.DEFAULT)))
            else r.copy(photo = null)
        }
    }.getOrNull()
}
