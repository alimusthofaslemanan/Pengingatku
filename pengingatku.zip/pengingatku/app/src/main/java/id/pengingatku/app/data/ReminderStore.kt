package id.pengingatku.app.data

import android.content.Context
import id.pengingatku.app.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime

/** Penyimpanan lokal (SharedPreferences + JSON), dibaca oleh aplikasi dan widget. */
object ReminderStore {
    private const val PREFS = "pengingatku"
    private const val KEY = "reminders"

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(ctx: Context): List<Reminder> {
        val raw = prefs(ctx).getString(KEY, null) ?: return DummyData.all()
        val arr = runCatching { JSONArray(raw) }.getOrNull() ?: return DummyData.all()
        val out = mutableListOf<Reminder>()
        for (i in 0 until arr.length()) {
            runCatching {
                val o = arr.getJSONObject(i)
                out.add(
                    Reminder(
                        id = o.getLong("id"),
                        title = o.getString("title"),
                        category = Category.valueOf(o.getString("cat")),
                        date = LocalDate.parse(o.getString("date")),
                        time = LocalTime.parse(o.getString("time")),
                        recurrence = Recurrence.valueOf(o.getString("rec")),
                        description = o.optString("desc", ""),
                        colorArgb = o.getLong("color"),
                        pinned = o.optBoolean("pinned", false)
                    )
                )
            }
        }
        return out
    }

    fun save(ctx: Context, list: List<Reminder>) {
        val arr = JSONArray()
        list.forEach { r ->
            arr.put(JSONObject().apply {
                put("id", r.id)
                put("title", r.title)
                put("cat", r.category.name)
                put("date", r.date.toString())
                put("time", r.time.toString())
                put("rec", r.recurrence.name)
                put("desc", r.description)
                put("color", r.colorArgb)
                put("pinned", r.pinned)
            })
        }
        prefs(ctx).edit().putString(KEY, arr.toString()).apply()
    }

    fun loadTheme(ctx: Context): Pair<String, Boolean> =
        prefs(ctx).getString("theme", "SYSTEM")!! to prefs(ctx).getBoolean("dynamic", false)

    fun saveTheme(ctx: Context, mode: String, dynamic: Boolean) {
        prefs(ctx).edit().putString("theme", mode).putBoolean("dynamic", dynamic).apply()
    }
}
