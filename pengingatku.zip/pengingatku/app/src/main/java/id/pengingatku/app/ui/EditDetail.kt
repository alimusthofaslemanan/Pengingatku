package id.pengingatku.app.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import id.pengingatku.app.data.PhotoStorage
import id.pengingatku.app.domain.NextOccurrence
import id.pengingatku.app.domain.countdownText
import id.pengingatku.app.domain.idLong
import id.pengingatku.app.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

@Composable
fun EditScreen(
    initial: Reminder?,
    customCategories: List<Pair<String, String>>,
    onAddCategory: (String, String) -> Unit,
    onSave: (Reminder) -> Unit,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var desc by remember { mutableStateOf(initial?.description ?: "") }
    var date by remember { mutableStateOf(initial?.date ?: LocalDate.now()) }
    var time by remember { mutableStateOf(initial?.time ?: LocalTime.of(8, 0)) }
    var allDay by remember { mutableStateOf(initial?.allDay ?: true) }
    var rec by remember { mutableStateOf(initial?.recurrence ?: Recurrence.YEARLY) }
    var interval by remember { mutableStateOf(initial?.interval ?: 1) }
    var mask by remember { mutableStateOf(initial?.weekdayMask ?: 0) }
    var cat by remember { mutableStateOf(initial?.category ?: Category.BIRTHDAY) }
    var customCat by remember {
        mutableStateOf(initial?.let { i -> i.catName?.let { n -> n to (i.catEmoji ?: "📌") } })
    }
    var icon by remember { mutableStateOf(initial?.icon) }
    var color by remember { mutableStateOf(initial?.colorArgb ?: PALETTE[0]) }
    var photo by remember { mutableStateOf(initial?.photo) }
    var notify by remember { mutableStateOf(initial?.notify ?: defaultNotify(Recurrence.YEARLY)) }
    var notifyTouched by remember { mutableStateOf(initial != null) }
    var allDayTouched by remember { mutableStateOf(initial != null) }

    var showNewCat by remember { mutableStateOf(false) }
    var newEmoji by remember { mutableStateOf("") }
    var newName by remember { mutableStateOf("") }
    var customNum by remember { mutableStateOf("") }
    var customUnit by remember { mutableStateOf(1) }

    // Foto baru yang belum disimpan dibersihkan bila form ditutup tanpa menyimpan.
    val imported = remember { mutableStateListOf<String>() }
    var saved by remember { mutableStateOf(false) }
    var savedPhoto by remember { mutableStateOf<String?>(null) }
    DisposableEffect(Unit) {
        onDispose {
            imported.filter { !(saved && it == savedPhoto) }.forEach { PhotoStorage.delete(ctx, it) }
        }
    }

    fun adopt(uri: Uri?) {
        if (uri == null) return
        scope.launch(Dispatchers.IO) {
            PhotoStorage.import(ctx, uri)?.let { name -> imported.add(name); photo = name }
        }
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { adopt(it) }
    val cameraFile = remember { File(File(ctx.cacheDir, "camera").apply { mkdirs() }, "capture.jpg") }
    val cameraUri = remember { FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", cameraFile) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) adopt(cameraUri)
    }
    val preview = remember(photo) { photo?.let { PhotoStorage.load(ctx, it) } }
    val shownMask = if (mask == 0) dayBit(date.dayOfWeek) else mask

    Surface(
        Modifier.fillMaxSize().background(appBrush()),
        color = Color.Transparent,
        contentColor = MaterialTheme.colorScheme.onBackground
    ) {
        Column(
            Modifier.systemBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onClose) { Text("←", fontSize = 22.sp) }
                Text(
                    if (initial == null) "Tambah Pengingat" else "Edit Pengingat",
                    style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold
                )
            }

            // ---- Foto
            Text("Foto", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(88.dp).clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    if (preview != null) {
                        Image(
                            bitmap = preview.asImageBitmap(), contentDescription = null,
                            modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                        )
                    } else {
                        Text(icon ?: customCat?.second ?: cat.emoji, fontSize = 32.sp)
                    }
                }
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }) { Text("🖼 Galeri") }
                        OutlinedButton(onClick = { camera.launch(cameraUri) }) { Text("📷 Kamera") }
                    }
                    if (photo != null) TextButton(onClick = { photo = null }) { Text("Hapus foto") }
                }
            }

            OutlinedTextField(
                title, { title = it }, label = { Text("Nama peristiwa") },
                singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)
            )

            // ---- Tanggal & waktu
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(
                    onClick = {
                        DatePickerDialog(ctx, { _, y, m, d -> date = LocalDate.of(y, m + 1, d) },
                            date.year, date.monthValue - 1, date.dayOfMonth).show()
                    },
                    Modifier.weight(1f)
                ) { Text("📅 ${date.idLong()}") }
                if (!allDay) {
                    OutlinedButton(
                        onClick = {
                            TimePickerDialog(ctx, { _, h, mi -> time = LocalTime.of(h, mi) },
                                time.hour, time.minute, true).show()
                        }
                    ) { Text("🕗 %02d:%02d".format(time.hour, time.minute)) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Sepanjang hari (tanpa jam)", fontWeight = FontWeight.SemiBold)
                    Text(
                        "Tetap \"Hari ini\" seharian, notifikasi pukul 08.00",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(allDay, { allDay = it; allDayTouched = true })
            }

            // ---- Pengulangan
            Text("Jenis pengulangan", fontWeight = FontWeight.SemiBold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Recurrence.values().toList()) { r ->
                    FilterChip(rec == r, {
                        rec = r
                        if (!notifyTouched) notify = defaultNotify(r)
                        if (!allDayTouched) allDay = r != Recurrence.DAILY && r != Recurrence.WEEKLY
                    }, label = { Text(r.label) })
                }
            }
            if (rec != Recurrence.ONCE) {
                val unit = when (rec) {
                    Recurrence.DAILY -> "hari"
                    Recurrence.WEEKLY -> "minggu"
                    Recurrence.YEARLY -> "tahun"
                    else -> "bulan"
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Ulangi setiap")
                    OutlinedButton(
                        onClick = { if (interval > 1) interval = interval - 1 },
                        contentPadding = PaddingValues(0.dp), modifier = Modifier.size(40.dp)
                    ) { Text("−") }
                    Text("$interval $unit", fontWeight = FontWeight.Bold)
                    OutlinedButton(
                        onClick = { if (interval < 30) interval = interval + 1 },
                        contentPadding = PaddingValues(0.dp), modifier = Modifier.size(40.dp)
                    ) { Text("＋") }
                }
            }
            if (rec == Recurrence.WEEKLY) {
                Text("Pada hari", fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(7) { i ->
                        FilterChip((shownMask and (1 shl i)) != 0, {
                            val nm = shownMask xor (1 shl i)
                            if (nm != 0) mask = nm
                        }, label = { Text(DAY_SHORT[i]) })
                    }
                    item {
                        FilterChip(shownMask == WEEKDAYS_MASK, { mask = WEEKDAYS_MASK }, label = { Text("Sen–Jum") })
                    }
                }
            }
            if (rec == Recurrence.MONTHLY) {
                Text("Setiap tanggal ${date.dayOfMonth}", style = MaterialTheme.typography.bodySmall)
            }
            if (rec == Recurrence.MONTHLY_NTH) {
                Text(
                    "Setiap minggu ke-${(date.dayOfMonth - 1) / 7 + 1} hari ${DAY_NAMES[date.dayOfWeek.value - 1]} (mengikuti tanggal yang dipilih)",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            // ---- Kategori & ikon
            Text("Kategori", fontWeight = FontWeight.SemiBold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Category.values().toList()) { c ->
                    FilterChip(customCat == null && cat == c, { cat = c; customCat = null },
                        label = { Text("${c.emoji} ${c.label}") })
                }
                items(customCategories) { (n, e) ->
                    FilterChip(customCat?.first == n, { customCat = n to e; cat = Category.OTHER },
                        label = { Text("$e $n") })
                }
                item { AssistChip(onClick = { showNewCat = true }, label = { Text("＋ Baru") }) }
            }
            Text("Ikon", fontWeight = FontWeight.SemiBold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(icon == null, { icon = null }, label = { Text("Otomatis") }) }
                items(ICONS) { e -> FilterChip(icon == e, { icon = e }, label = { Text(e) }) }
            }

            // ---- Notifikasi
            Text("Notifikasi", fontWeight = FontWeight.SemiBold)
            val options = (NOTIFY_OPTIONS.map { it.first } + notify).distinct().sorted()
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(options) { m ->
                    FilterChip(m in notify, {
                        notifyTouched = true
                        notify = if (m in notify) notify - m else (notify + m).sortedDescending()
                    }, label = { Text(offsetLabel(m)) })
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    customNum, { customNum = it.filter { c -> c.isDigit() }.take(3) },
                    label = { Text("Custom") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.width(96.dp), shape = RoundedCornerShape(16.dp)
                )
                listOf(1 to "mnt", 60 to "jam", 1440 to "hari").forEach { (u, l) ->
                    FilterChip(customUnit == u, { customUnit = u }, label = { Text(l) })
                }
                TextButton(onClick = {
                    val v = customNum.toIntOrNull()
                    if (v != null && v > 0) {
                        val minutes = (v * customUnit).coerceAtMost(60 * 24 * 365)
                        notifyTouched = true
                        notify = (notify + minutes).distinct().sortedDescending()
                        customNum = ""
                    }
                }) { Text("Tambah") }
            }

            OutlinedTextField(
                desc, { desc = it }, label = { Text("Deskripsi (opsional)") },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), minLines = 2
            )
            Text("Warna tema", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PALETTE.forEach { c ->
                    Box(
                        Modifier.size(36.dp).clip(CircleShape).background(Color(c))
                            .border(if (color == c) 3.dp else 0.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                            .clickable { color = c }
                    )
                }
            }
            Button(
                onClick = {
                    saved = true
                    savedPhoto = photo
                    onSave(
                        Reminder(
                            id = initial?.id ?: 0, title = title.trim(), category = cat,
                            date = date, time = time, recurrence = rec, description = desc.trim(),
                            colorArgb = color, pinned = initial?.pinned ?: false,
                            photo = photo, notify = notify,
                            interval = if (rec == Recurrence.ONCE) 1 else interval,
                            weekdayMask = if (rec == Recurrence.WEEKLY) mask else 0,
                            allDay = allDay, archived = initial?.archived ?: false,
                            catName = customCat?.first, catEmoji = customCat?.second, icon = icon
                        )
                    )
                },
                enabled = title.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Simpan Pengingat") }
        }
    }

    if (showNewCat) {
        AlertDialog(
            onDismissRequest = { showNewCat = false },
            title = { Text("Kategori baru") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(newEmoji, { newEmoji = it.take(4) },
                        label = { Text("Ikon (emoji)") }, singleLine = true)
                    OutlinedTextField(newName, { newName = it },
                        label = { Text("Nama kategori") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(
                    enabled = newName.isNotBlank(),
                    onClick = {
                        val e = newEmoji.trim().ifBlank { "📌" }
                        val n = newName.trim()
                        onAddCategory(n, e)
                        customCat = n to e
                        cat = Category.OTHER
                        newName = ""; newEmoji = ""
                        showNewCat = false
                    }
                ) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { showNewCat = false }) { Text("Batal") } }
        )
    }
}

@Composable
fun DetailScreen(
    r: Reminder, now: LocalDateTime,
    onBack: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit,
    onPin: () -> Unit, onArchive: () -> Unit
) {
    val ctx = LocalContext.current
    val next = NextOccurrence.of(r, now)
    val shownDate = (next?.toLocalDate() ?: r.date).idLong()
    var confirm by remember { mutableStateOf(false) }

    Surface(
        Modifier.fillMaxSize().background(appBrush()),
        color = Color.Transparent,
        contentColor = MaterialTheme.colorScheme.onBackground
    ) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Box {
                Cover(r, Modifier.fillMaxWidth().height(280.dp), 96.sp)
                TextButton(onClick = onBack, modifier = Modifier.systemBarsPadding()) {
                    Text("←", fontSize = 26.sp, color = Color.White)
                }
            }
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("${r.emoji} ${r.title}",
                    style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(shownDate, color = MaterialTheme.colorScheme.onSurfaceVariant)
                CountdownChip(if (r.archived) "Diarsipkan" else countdownText(next, now), Modifier.fillMaxWidth())
                Text("Jenis", fontWeight = FontWeight.SemiBold)
                Text(recurrenceText(r) + if (r.allDay) " · sepanjang hari" else " · %02d:%02d".format(r.time.hour, r.time.minute))
                Text("Kategori", fontWeight = FontWeight.SemiBold)
                Text("${r.emoji} ${r.categoryLabel}")
                if (r.notify.isNotEmpty()) {
                    Text("Notifikasi", fontWeight = FontWeight.SemiBold)
                    Text(r.notify.joinToString(", ") { offsetLabel(it) })
                }
                if (r.description.isNotBlank()) {
                    Text("Deskripsi", fontWeight = FontWeight.SemiBold)
                    Text("\"${r.description}\"")
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = onEdit, Modifier.weight(1f)) { Text("Edit") }
                    FilledTonalButton(onClick = onPin, Modifier.weight(1f)) { Text(if (r.pinned) "Lepas 📌" else "Sematkan") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = onArchive, Modifier.weight(1f)) {
                        Text(if (r.archived) "Pulihkan" else "Arsipkan")
                    }
                    FilledTonalButton(
                        onClick = {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT,
                                    "${r.emoji} ${r.title}\n$shownDate\n${countdownText(next, now)}")
                            }
                            ctx.startActivity(Intent.createChooser(send, "Bagikan"))
                        },
                        Modifier.weight(1f)
                    ) { Text("Bagikan") }
                }
                FilledTonalButton(onClick = { confirm = true }, Modifier.fillMaxWidth()) { Text("Hapus") }
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Hapus pengingat?") },
            text = { Text("\"${r.title}\" akan dihapus.") },
            confirmButton = { TextButton(onClick = { confirm = false; onDelete() }) { Text("Hapus") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Batal") } }
        )
    }
}
