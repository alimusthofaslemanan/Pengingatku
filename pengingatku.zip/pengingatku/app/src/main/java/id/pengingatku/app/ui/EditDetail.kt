package id.pengingatku.app.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import id.pengingatku.app.data.PhotoStorage
import id.pengingatku.app.domain.NextOccurrence
import id.pengingatku.app.domain.countdownText
import id.pengingatku.app.domain.idLong
import id.pengingatku.app.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

@Composable
fun EditScreen(initial: Reminder?, onSave: (Reminder) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var desc by remember { mutableStateOf(initial?.description ?: "") }
    var date by remember { mutableStateOf(initial?.date ?: LocalDate.now()) }
    var time by remember { mutableStateOf(initial?.time ?: LocalTime.of(8, 0)) }
    var rec by remember { mutableStateOf(initial?.recurrence ?: Recurrence.YEARLY) }
    var cat by remember { mutableStateOf(initial?.category ?: Category.BIRTHDAY) }
    var color by remember { mutableStateOf(initial?.colorArgb ?: PALETTE[0]) }
    var photo by remember { mutableStateOf(initial?.photo) }
    var notify by remember { mutableStateOf(initial?.notify ?: defaultNotify(Recurrence.YEARLY)) }
    var notifyTouched by remember { mutableStateOf(initial != null) }

    // Foto baru yang belum disimpan dibersihkan bila form ditutup tanpa menyimpan.
    val imported = remember { mutableStateListOf<String>() }
    var saved by remember { mutableStateOf(false) }
    var savedPhoto by remember { mutableStateOf<String?>(null) }
    DisposableEffect(Unit) {
        onDispose {
            imported.filter { !(saved && it == savedPhoto) }.forEach { PhotoStorage.delete(ctx, it) }
        }
    }

    fun adopt(uri: Uri?) {
        if (uri == null) return
        scope.launch(Dispatchers.IO) {
            PhotoStorage.import(ctx, uri)?.let { name -> imported.add(name); photo = name }
        }
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { adopt(it) }
    val cameraFile = remember { File(File(ctx.cacheDir, "camera").apply { mkdirs() }, "capture.jpg") }
    val cameraUri = remember { FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", cameraFile) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) adopt(cameraUri)
    }
    val preview = remember(photo) { photo?.let { PhotoStorage.load(ctx, it) } }

    Surface(
        Modifier.fillMaxSize().background(appBrush()),
        color = Color.Transparent,
        contentColor = MaterialTheme.colorScheme.onBackground
    ) {
        Column(
            Modifier.systemBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onClose) { Text("←", fontSize = 22.sp) }
                Text(
                    if (initial == null) "Tambah Pengingat" else "Edit Pengingat",
                    style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold
                )
            }
            Text("Foto", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(88.dp).clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    if (preview != null) {
                        Image(
                            bitmap = preview.asImageBitmap(), contentDescription = null,
                            modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                        )
                    } else {
                        Text(cat.emoji, fontSize = 32.sp)
                    }
                }
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }) { Text("🖼 Galeri") }
                        OutlinedButton(onClick = { camera.launch(cameraUri) }) { Text("📷 Kamera") }
                    }
                    if (photo != null) {
                        TextButton(onClick = { photo = null }) { Text("Hapus foto") }
                    }
                }
            }
            OutlinedTextField(
                title, { title = it }, label = { Text("Nama peristiwa") },
                singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        DatePickerDialog(ctx, { _, y, m, d -> date = LocalDate.of(y, m + 1, d) },
                            date.year, date.monthValue - 1, date.dayOfMonth).show()
                    },
                    Modifier.weight(1f)
                ) { Text("📅 ${date.idLong()}") }
                OutlinedButton(
                    onClick = {
                        TimePickerDialog(ctx, { _, h, mi -> time = LocalTime.of(h, mi) },
                            time.hour, time.minute, true).show()
                    }
                ) { Text("🕗 %02d:%02d".format(time.hour, time.minute)) }
            }
            Text("Jenis pengulangan", fontWeight = FontWeight.SemiBold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Recurrence.values().toList()) { r ->
                    FilterChip(rec == r, {
                        rec = r
                        if (!notifyTouched) notify = defaultNotify(r)
                    }, label = { Text(r.label) })
                }
            }
            Text("Kategori", fontWeight = FontWeight.SemiBold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Category.values().toList()) { c ->
                    FilterChip(cat == c, { cat = c }, label = { Text("${c.emoji} ${c.label}") })
                }
            }
            Text("Notifikasi", fontWeight = FontWeight.SemiBold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(NOTIFY_OPTIONS) { (m, label) ->
                    FilterChip(m in notify, {
                        notifyTouched = true
                        notify = if (m in notify) notify - m else (notify + m).sortedDescending()
                    }, label = { Text(label) })
                }
            }
            OutlinedTextField(
                desc, { desc = it }, label = { Text("Deskripsi (opsional)") },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), minLines = 2
            )
            Text("Warna tema", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PALETTE.forEach { c ->
                    Box(
                        Modifier.size(36.dp).clip(CircleShape).background(Color(c))
                            .border(if (color == c) 3.dp else 0.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                            .clickable { color = c }
                    )
                }
            }
            Button(
                onClick = {
                    saved = true
                    savedPhoto = photo
                    onSave(
                        Reminder(
                            id = initial?.id ?: 0, title = title.trim(), category = cat,
                            date = date, time = time, recurrence = rec, description = desc.trim(),
                            colorArgb = color, pinned = initial?.pinned ?: false,
                            photo = photo, notify = notify
                        )
                    )
                },
                enabled = title.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Simpan Pengingat") }
        }
    }
}

@Composable
fun DetailScreen(
    r: Reminder, now: LocalDateTime,
    onBack: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit, onPin: () -> Unit
) {
    val ctx = LocalContext.current
    val next = NextOccurrence.of(r, now)
    val shownDate = (next?.toLocalDate() ?: r.date).idLong()
    var confirm by remember { mutableStateOf(false) }

    Surface(
        Modifier.fillMaxSize().background(appBrush()),
        color = Color.Transparent,
        contentColor = MaterialTheme.colorScheme.onBackground
    ) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Box {
                Cover(r, Modifier.fillMaxWidth().height(280.dp), 96.sp)
                TextButton(onClick = onBack, modifier = Modifier.systemBarsPadding()) {
                    Text("←", fontSize = 26.sp, color = Color.White)
                }
            }
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("${r.category.emoji} ${r.title}",
                    style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(shownDate, color = MaterialTheme.colorScheme.onSurfaceVariant)
                CountdownChip(countdownText(next, now), Modifier.fillMaxWidth())
                Text("Jenis", fontWeight = FontWeight.SemiBold)
                Text(r.recurrence.label)
                if (r.description.isNotBlank()) {
                    Text("Deskripsi", fontWeight = FontWeight.SemiBold)
                    Text("\"${r.description}\"")
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = onEdit, Modifier.weight(1f)) { Text("Edit") }
                    FilledTonalButton(onClick = onPin, Modifier.weight(1f)) { Text(if (r.pinned) "Lepas 📌" else "Sematkan") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { confirm = true }, Modifier.weight(1f)) { Text("Hapus") }
                    FilledTonalButton(
                        onClick = {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT,
                                    "${r.category.emoji} ${r.title}\n$shownDate\n${countdownText(next, now)}")
                            }
                            ctx.startActivity(Intent.createChooser(send, "Bagikan"))
                        },
                        Modifier.weight(1f)
                    ) { Text("Bagikan") }
                }
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Hapus pengingat?") },
            text = { Text("\"${r.title}\" akan dihapus.") },
            confirmButton = { TextButton(onClick = { confirm = false; onDelete() }) { Text("Hapus") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Batal") } }
        )
    }
}
