package id.pengingatku.app.model

import java.time.LocalDate
import java.time.LocalTime

enum class Recurrence(val label: String) {
    ONCE("Sekali"),
    DAILY("Setiap Hari"),
    WEEKLY("Setiap Minggu"),
    MONTHLY("Setiap Bulan"),
    YEARLY("Setiap Tahun")
}

enum class Category(val label: String, val emoji: String) {
    LOVE("Cinta", "❤️"),
    BIRTHDAY("Ulang Tahun", "🎂"),
    WEDDING("Pernikahan", "💍"),
    FAMILY("Keluarga", "👨‍👩‍👧"),
    RELIGION("Keagamaan", "🕌"),
    EDUCATION("Pendidikan", "📚"),
    WORK("Pekerjaan", "💼"),
    TRIP("Liburan", "✈️"),
    EVENT("Acara", "🎉"),
    OTHER("Lainnya", "📅")
}

data class Reminder(
    val id: Long,
    val title: String,
    val category: Category,
    val date: LocalDate,
    val time: LocalTime = LocalTime.of(8, 0),
    val recurrence: Recurrence = Recurrence.ONCE,
    val description: String = "",
    val colorArgb: Long = 0xFF0F6B4F,
    val pinned: Boolean = false
)

val PALETTE: List<Long> = listOf(
    0xFF0F6B4F, 0xFF4CAF7A, 0xFF29A3D9, 0xFF7E57C2, 0xFFE91E63, 0xFFFF9800
)
