package id.pengingatku.app.model

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime

enum class Recurrence(val label: String) {
    ONCE("Sekali"),
    DAILY("Setiap Hari"),
    WEEKLY("Setiap Minggu"),
    MONTHLY("Setiap Bulan"),
    YEARLY("Setiap Tahun"),
    MONTHLY_NTH("Minggu ke-N tiap bulan")
}

enum class Category(val label: String, val emoji: String) {
    LOVE("Cinta", "❤️"),
    BIRTHDAY("Ulang Tahun", "🎂"),
    WEDDING("Pernikahan", "💍"),
    FAMILY("Keluarga", "👨‍👩‍👧"),
    RELIGION("Keagamaan", "🕌"),
    EDUCATION("Pendidikan", "📚"),
    WORK("Pekerjaan", "💼"),
    TRIP("Liburan", "✈️"),
    EVENT("Acara", "🎉"),
    OTHER("Lainnya", "📅")
}

data class Reminder(
    val id: Long,
    val title: String,
    val category: Category,
    val date: LocalDate,
    val time: LocalTime = LocalTime.of(8, 0),
    val recurrence: Recurrence = Recurrence.ONCE,
    val description: String = "",
    val colorArgb: Long = 0xFF0F6B4F,
    val pinned: Boolean = false,
    val photo: String? = null,
    val notify: List<Int> = listOf(0),
    /** Ulangi setiap N (hari/minggu/bulan/tahun). */
    val interval: Int = 1,
    /** Bit 0 = Senin ... bit 6 = Ahad. 0 = ikuti hari dari tanggal awal. */
    val weekdayMask: Int = 0,
    /** Tanpa jam: tetap "Hari ini" sepanjang hari, notifikasi pukul 08.00. */
    val allDay: Boolean = false,
    val archived: Boolean = false,
    /** Kategori buatan sendiri (menimpa [category]). */
    val catName: String? = null,
    val catEmoji: String? = null,
    /** Ikon khusus peristiwa ini. */
    val icon: String? = null
)

val Reminder.emoji: String get() = icon ?: catEmoji ?: category.emoji
val Reminder.categoryLabel: String get() = catName ?: category.label
val Reminder.categoryKey: String get() = catName ?: category.name

val PALETTE: List<Long> = listOf(
    0xFF0F6B4F, 0xFF4CAF7A, 0xFF29A3D9, 0xFF7E57C2, 0xFFE91E63, 0xFFFF9800
)

val ICONS = listOf("🎂", "❤️", "💍", "🕌", "📚", "💼", "✈️", "🎉", "🏠", "💊", "💧", "🎓", "👶", "🐱", "🎁", "⭐")

val DAY_NAMES = listOf("Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Ahad")
val DAY_SHORT = listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")
const val WEEKDAYS_MASK = 31

fun dayBit(d: DayOfWeek): Int = 1 shl (d.value - 1)
fun Reminder.effectiveMask(): Int = if (weekdayMask == 0) dayBit(date.dayOfWeek) else weekdayMask

/** Menit sebelum acara; 0 = Hari H / tepat waktu. */
fun offsetLabel(min: Int): String = when {
    min == 0 -> "Hari H"
    min % 1440 == 0 -> "${min / 1440} hari"
    min % 60 == 0 -> "${min / 60} jam"
    else -> "$min menit"
}

val NOTIFY_OPTIONS: List<Pair<Int, String>> =
    listOf(0, 1, 10, 60, 1440, 4320, 10080).map { it to offsetLabel(it) }

fun defaultNotify(rec: Recurrence): List<Int> =
    if (rec == Recurrence.YEARLY) listOf(10080, 1440, 0) else listOf(0)

fun recurrenceText(r: Reminder): String {
    val n = r.interval.coerceAtLeast(1)
    return when (r.recurrence) {
        Recurrence.ONCE -> "Sekali"
        Recurrence.DAILY -> if (n == 1) "Setiap hari" else "Setiap $n hari"
        Recurrence.WEEKLY -> {
            val mask = r.effectiveMask()
            if (n == 1 && mask == WEEKDAYS_MASK) "Senin–Jumat"
            else {
                val days = DAY_NAMES.filterIndexed { i, _ -> (mask and (1 shl i)) != 0 }.joinToString(", ")
                if (n == 1) "Setiap minggu ($days)" else "Setiap $n minggu ($days)"
            }
        }
        Recurrence.MONTHLY ->
            if (n == 1) "Setiap bulan (tgl ${r.date.dayOfMonth})" else "Setiap $n bulan (tgl ${r.date.dayOfMonth})"
        Recurrence.YEARLY -> if (n == 1) "Setiap tahun" else "Setiap $n tahun"
        Recurrence.MONTHLY_NTH -> {
            val w = (r.date.dayOfMonth - 1) / 7 + 1
            val day = DAY_NAMES[r.date.dayOfWeek.value - 1]
            val every = if (n == 1) "setiap bulan" else "setiap $n bulan"
            "Minggu ke-$w $day $every"
        }
    }
}
