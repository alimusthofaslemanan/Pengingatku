package id.pengingatku.app.model

import java.time.LocalDate
import java.time.LocalTime

enum class Recurrence(val label: String) {
    ONCE("Sekali"),
    DAILY("Setiap Hari"),
    WEEKLY("Setiap Minggu"),
    MONTHLY("Setiap Bulan"),
    YEARLY("Setiap Tahun")
}

enum class Category(val label: String, val emoji: String) {
    LOVE("Cinta", "❤️"),
    BIRTHDAY("Ulang Tahun", "🎂"),
    WEDDING("Pernikahan", "💍"),
    FAMILY("Keluarga", "👨‍👩‍👧"),
    RELIGION("Keagamaan", "🕌"),
    EDUCATION("Pendidikan", "📚"),
    WORK("Pekerjaan", "💼"),
    TRIP("Liburan", "✈️"),
    EVENT("Acara", "🎉"),
    OTHER("Lainnya", "📅")
}

data class Reminder(
    val id: Long,
    val title: String,
    val category: Category,
    val date: LocalDate,
    val time: LocalTime = LocalTime.of(8, 0),
    val recurrence: Recurrence = Recurrence.ONCE,
    val description: String = "",
    val colorArgb: Long = 0xFF0F6B4F,
    val pinned: Boolean = false,
    val photo: String? = null,
    val notify: List<Int> = listOf(0)
)

/** Menit sebelum acara; 0 = tepat waktu / Hari H. */
val NOTIFY_OPTIONS: List<Pair<Int, String>> = listOf(
    0 to "Hari H", 1 to "1 menit", 10 to "10 menit", 60 to "1 jam",
    1440 to "1 hari", 4320 to "3 hari", 10080 to "7 hari"
)

fun defaultNotify(rec: Recurrence): List<Int> =
    if (rec == Recurrence.YEARLY) listOf(10080, 1440, 0) else listOf(0)

fun offsetLabel(min: Int): String = when (min) {
    1 -> "1 menit"; 10 -> "10 menit"; 60 -> "1 jam"
    1440 -> "1 hari"; 4320 -> "3 hari"; 10080 -> "7 hari"
    else -> "$min menit"
}

val PALETTE: List<Long> = listOf(
    0xFF0F6B4F, 0xFF4CAF7A, 0xFF29A3D9, 0xFF7E57C2, 0xFFE91E63, 0xFFFF9800
)
