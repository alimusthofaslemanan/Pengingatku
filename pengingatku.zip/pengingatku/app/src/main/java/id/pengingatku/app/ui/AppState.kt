package id.pengingatku.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import id.pengingatku.app.domain.NextOccurrence
import id.pengingatku.app.model.DummyData
import id.pengingatku.app.model.Reminder
import java.time.LocalDateTime

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** State sementara di memori. Tahap 3 akan diganti Room + ViewModel. */
class AppState {
    val reminders = mutableStateListOf<Reminder>().apply { addAll(DummyData.all()) }
    var themeMode by mutableStateOf(ThemeMode.SYSTEM)
    var dynamicColor by mutableStateOf(false)
    private var nextId = 100L

    fun upsert(r: Reminder) {
        val i = reminders.indexOfFirst { it.id == r.id }
        if (i >= 0) reminders[i] = r else reminders.add(r.copy(id = nextId++))
    }

    fun remove(id: Long) { reminders.removeAll { it.id == id } }

    fun togglePin(id: Long) {
        val i = reminders.indexOfFirst { it.id == id }
        if (i >= 0) reminders[i] = reminders[i].let { it.copy(pinned = !it.pinned) }
    }

    fun upcoming(now: LocalDateTime): List<Pair<Reminder, LocalDateTime>> =
        reminders.mapNotNull { r -> NextOccurrence.of(r, now)?.let { r to it } }
            .sortedBy { it.second }
}
