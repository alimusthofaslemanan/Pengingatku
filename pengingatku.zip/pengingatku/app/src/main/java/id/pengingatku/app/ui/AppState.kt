package id.pengingatku.app.ui

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import id.pengingatku.app.data.ReminderStore
import id.pengingatku.app.domain.NextOccurrence
import id.pengingatku.app.model.Reminder
import id.pengingatku.app.widget.WidgetUpdater
import java.time.LocalDateTime

enum class ThemeMode { SYSTEM, LIGHT, DARK }

class AppState(context: Context) {
    private val app = context.applicationContext
    val reminders = mutableStateListOf<Reminder>().apply { addAll(ReminderStore.load(app)) }

    private val savedTheme = ReminderStore.loadTheme(app)
    private var themeState by mutableStateOf(
        runCatching { ThemeMode.valueOf(savedTheme.first) }.getOrDefault(ThemeMode.SYSTEM)
    )
    private var dynamicState by mutableStateOf(savedTheme.second)

    var themeMode: ThemeMode
        get() = themeState
        set(v) { themeState = v; ReminderStore.saveTheme(app, v.name, dynamicState) }

    var dynamicColor: Boolean
        get() = dynamicState
        set(v) { dynamicState = v; ReminderStore.saveTheme(app, themeState.name, v) }

    private fun persist() {
        ReminderStore.save(app, reminders.toList())
        WidgetUpdater.refreshAsync(app)
    }

    fun upsert(r: Reminder) {
        val i = reminders.indexOfFirst { it.id == r.id }
        if (i >= 0) reminders[i] = r
        else reminders.add(r.copy(id = (reminders.maxOfOrNull { it.id } ?: 0L) + 1L))
        persist()
    }

    fun remove(id: Long) { reminders.removeAll { it.id == id }; persist() }

    fun togglePin(id: Long) {
        val i = reminders.indexOfFirst { it.id == id }
        if (i >= 0) { reminders[i] = reminders[i].let { it.copy(pinned = !it.pinned) }; persist() }
    }

    fun upcoming(now: LocalDateTime): List<Pair<Reminder, LocalDateTime>> =
        reminders.mapNotNull { r -> NextOccurrence.of(r, now)?.let { r to it } }
            .sortedBy { it.second }
}
