package id.pengingatku.app.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.pengingatku.app.domain.countdownText
import id.pengingatku.app.domain.idLong
import id.pengingatku.app.domain.idShort
import id.pengingatku.app.model.Reminder
import java.time.LocalDateTime

/** Pengganti foto: gradient warna tema + ikon kategori. */
@Composable
fun Cover(r: Reminder, modifier: Modifier = Modifier, emojiSize: TextUnit = 32.sp) {
    val c = Color(r.colorArgb)
    Box(
        modifier.background(Brush.linearGradient(listOf(c, c.copy(alpha = 0.5f)))),
        contentAlignment = Alignment.Center
    ) { Text(r.category.emoji, fontSize = emojiSize) }
}

@Composable
fun CountdownChip(text: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("⏱", fontSize = 16.sp)
            Spacer(Modifier.width(8.dp))
            Text(
                text, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }
}

@Composable
fun HeroCard(r: Reminder, next: LocalDateTime?, now: LocalDateTime, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Row(Modifier.fillMaxWidth().height(180.dp)) {
            Cover(r, Modifier.width(120.dp).fillMaxHeight(), 52.sp)
            Column(
                Modifier.weight(1f).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(r.title, style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text((next?.toLocalDate() ?: r.date).idLong(),
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                CountdownChip("Tinggal " + countdownText(next, now).removeSuffix(" lagi"))
                if (r.description.isNotBlank()) {
                    Text(r.description, style = MaterialTheme.typography.bodySmall,
                        maxLines = 2, overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun ReminderRow(r: Reminder, next: LocalDateTime?, now: LocalDateTime, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Cover(r, Modifier.size(48.dp).clip(CircleShape), 22.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    (if (r.pinned) "📌 " else "") + r.title,
                    fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    "${(next?.toLocalDate() ?: r.date).idShort()} · ${r.recurrence.label}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                countdownText(next, now), style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
}
