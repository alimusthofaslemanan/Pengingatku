package id.pengingatku.app.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.pengingatku.app.data.PhotoStorage
import id.pengingatku.app.domain.countdownText
import id.pengingatku.app.domain.idLong
import id.pengingatku.app.domain.idShort
import id.pengingatku.app.model.Reminder
import id.pengingatku.app.model.categoryLabel
import id.pengingatku.app.model.emoji
import id.pengingatku.app.model.recurrenceText
import java.time.LocalDateTime

/** Latar gradien warna-warni untuk seluruh aplikasi. */
@Composable
fun appBrush(): Brush {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    return Brush.verticalGradient(
        if (dark) listOf(Color(0xFF0F4A39), Color(0xFF2B1D45), Color(0xFF0E1512))
        else listOf(Color(0xFFBDEBD5), Color(0xFFFFE0EA), Color(0xFFFFFBF7))
    )
}

@Composable
fun Banner() {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF0F6B4F), Color(0xFF1AA37A), Color(0xFF7E57C2))))
            .padding(20.dp)
    ) {
        Column {
            Text("Pengingatku", style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold, color = Color.White)
            Text("Jangan sampai lupa momen penting.", color = Color.White.copy(alpha = 0.88f))
        }
        Text("🔔", Modifier.align(Alignment.CenterEnd), fontSize = 44.sp)
    }
}

/** Foto peristiwa, atau gradient warna tema + ikon kategori bila tanpa foto. */
@Composable
fun Cover(r: Reminder, modifier: Modifier = Modifier, emojiSize: TextUnit = 32.sp) {
    val ctx = LocalContext.current
    val bmp = remember(r.photo) { r.photo?.let { PhotoStorage.load(ctx, it) } }
    if (bmp != null) {
        Image(
            bitmap = bmp.asImageBitmap(), contentDescription = null,
            modifier = modifier, contentScale = ContentScale.Crop
        )
        return
    }
    val c = Color(r.colorArgb)
    Box(
        modifier.background(Brush.linearGradient(listOf(c, c.copy(alpha = 0.5f)))),
        contentAlignment = Alignment.Center
    ) { Text(r.emoji, fontSize = emojiSize) }
}

@Composable
fun CountdownChip(text: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("⏱", fontSize = 16.sp)
            Spacer(Modifier.width(8.dp))
            Text(
                text, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }
}

@Composable
fun HeroCard(r: Reminder, next: LocalDateTime?, now: LocalDateTime, onClick: () -> Unit) {
    val c = Color(r.colorArgb)
    val white = Color.White
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent, contentColor = white)
    ) {
        Row(
            Modifier.fillMaxWidth().height(190.dp).background(
                Brush.linearGradient(listOf(c.copy(alpha = 0.92f), Color(0xFF7E57C2).copy(alpha = 0.85f)))
            )
        ) {
            if (r.photo != null) {
                Cover(r, Modifier.width(128.dp).fillMaxHeight(), 52.sp)
            } else {
                Box(
                    Modifier.width(128.dp).fillMaxHeight().background(white.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) { Text(r.emoji, fontSize = 54.sp) }
            }
            Column(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(r.title, style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text((next?.toLocalDate() ?: r.date).idLong(), color = white.copy(alpha = 0.88f))
                Surface(color = white.copy(alpha = 0.25f), contentColor = white, shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("⏱", fontSize = 16.sp)
                        Spacer(Modifier.width(8.dp))
                        Text("Tinggal " + countdownText(next, now).removeSuffix(" lagi"), fontWeight = FontWeight.Bold)
                    }
                }
                if (r.description.isNotBlank()) {
                    Text(r.description, style = MaterialTheme.typography.bodySmall,
                        maxLines = 2, overflow = TextOverflow.Ellipsis, color = white.copy(alpha = 0.9f))
                }
            }
        }
    }
}

@Composable
fun ReminderRow(r: Reminder, next: LocalDateTime?, now: LocalDateTime, onClick: () -> Unit) {
    val c = Color(r.colorArgb)
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = c.copy(alpha = 0.18f),
            contentColor = MaterialTheme.colorScheme.onSurface
        ),
        border = BorderStroke(1.dp, c.copy(alpha = 0.40f))
    ) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Cover(r, Modifier.size(50.dp).clip(CircleShape), 22.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    (if (r.pinned) "📌 " else "") + r.title,
                    fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    "${(next?.toLocalDate() ?: r.date).idShort()} · ${recurrenceText(r)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Surface(color = c.copy(alpha = 0.28f), shape = RoundedCornerShape(14.dp)) {
                Text(
                    if (r.archived) "Arsip" else countdownText(next, now),
                    Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
}
