package id.pengingatku.app.notify

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import id.pengingatku.app.EXTRA_REMINDER_ID
import id.pengingatku.app.MainActivity
import id.pengingatku.app.data.ReminderStore
import id.pengingatku.app.domain.NextOccurrence
import id.pengingatku.app.domain.idShort
import id.pengingatku.app.model.Reminder
import id.pengingatku.app.model.offsetLabel
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId

data class Trigger(val at: LocalDateTime, val r: Reminder, val offset: Int, val occ: LocalDateTime)

/**
 * Satu alarm untuk notifikasi terdekat. Saat alarm berbunyi, semua notifikasi yang jatuh
 * pada waktu itu ditampilkan, lalu alarm berikutnya dijadwalkan.
 */
object NotificationScheduler {
    const val CHANNEL = "pengingat"
    const val ACTION_NOTIFY = "id.pengingatku.app.NOTIFY"
    const val EXTRA_T0 = "t0"

    private val zone get() = ZoneId.systemDefault()
    private fun LocalDateTime.ms() = atZone(zone).toInstant().toEpochMilli()

    fun triggers(list: List<Reminder>, from: LocalDateTime): List<Trigger> =
        list.flatMap { r ->
            r.notify.distinct().mapNotNull { off ->
                val occ = NextOccurrence.of(r, from.plusMinutes(off.toLong())) ?: return@mapNotNull null
                Trigger(occ.minusMinutes(off.toLong()), r, off, occ)
            }
        }

    private fun pending(ctx: Context, t0: Long): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 1,
            Intent(ctx, NotifyReceiver::class.java).setAction(ACTION_NOTIFY).putExtra(EXTRA_T0, t0),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    fun rescheduleAll(ctx: Context, after: LocalDateTime = LocalDateTime.now()) {
        val app = ctx.applicationContext
        val am = app.getSystemService(AlarmManager::class.java)
        val first = triggers(ReminderStore.load(app), after).minByOrNull { it.at }
        if (first == null) {
            am.cancel(pending(app, 0L))
            return
        }
        val at = maxOf(first.at.ms(), System.currentTimeMillis() + 500)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(app, first.at.ms()))
    }

    fun fire(ctx: Context, t0Ms: Long) {
        val app = ctx.applicationContext
        val t0 = LocalDateTime.ofInstant(Instant.ofEpochMilli(t0Ms), zone)
        triggers(ReminderStore.load(app), t0).filter { it.at == t0 }.forEach { post(app, it) }
        rescheduleAll(app, maxOf(t0.plusSeconds(1), LocalDateTime.now().minusMinutes(60)))
    }

    private fun post(ctx: Context, t: Trigger) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Pengingat", NotificationManager.IMPORTANCE_HIGH)
        )
        val r = t.r
        val hhmm = "%02d:%02d".format(t.occ.hour, t.occ.minute)
        val head = when (t.offset) {
            0 -> "Hari ini pukul $hhmm"
            1440 -> "Besok pukul $hhmm"
            else -> "${offsetLabel(t.offset)} lagi · ${t.occ.toLocalDate().idShort()} $hhmm"
        }
        val body = if (r.description.isBlank()) head else "$head\n${r.description}"
        val open = PendingIntent.getActivity(
            ctx, (r.id % 100000).toInt(),
            Intent(ctx, MainActivity::class.java).apply {
                data = Uri.parse("pengingatku://reminder/${r.id}")
                putExtra(EXTRA_REMINDER_ID, r.id)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("${r.category.emoji} ${r.title}")
            .setContentText(head)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify((r.id * 31 + t.offset).toInt(), n)
    }
}

class NotifyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != NotificationScheduler.ACTION_NOTIFY) return
        NotificationScheduler.fire(context, intent.getLongExtra(NotificationScheduler.EXTRA_T0, 0L))
    }
}
