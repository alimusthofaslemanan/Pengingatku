package id.pengingatku.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/** Foto disimpan lokal di filesDir/photos, di-crop persegi dari tengah (maks 640 px). */
object PhotoStorage {
    private fun dir(ctx: Context) = File(ctx.applicationContext.filesDir, "photos").apply { mkdirs() }

    fun import(ctx: Context, uri: Uri): String? = runCatching {
        val src = decode(ctx, uri, 1024)
        val side = minOf(src.width, src.height)
        val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
        val target = minOf(side, 640)
        val out = if (target != side) Bitmap.createScaledBitmap(sq, target, target, true) else sq
        val name = "${UUID.randomUUID()}.jpg"
        FileOutputStream(File(dir(ctx), name)).use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        name
    }.getOrNull()

    fun load(ctx: Context, name: String): Bitmap? =
        runCatching { BitmapFactory.decodeFile(File(dir(ctx), name).path) }.getOrNull()

    fun loadScaled(ctx: Context, name: String, max: Int): Bitmap? =
        load(ctx, name)?.let {
            if (it.width > max) Bitmap.createScaledBitmap(it, max, max, true) else it
        }

    fun delete(ctx: Context, name: String) {
        File(dir(ctx), name).delete()
    }

    private fun decode(ctx: Context, uri: Uri, max: Int): Bitmap {
        if (Build.VERSION.SDK_INT >= 28) {
            val source = ImageDecoder.createSource(ctx.contentResolver, uri)
            return ImageDecoder.decodeBitmap(source) { dec, info, _ ->
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val s = maxOf(info.size.width, info.size.height)
                if (s > max) dec.setTargetSize(info.size.width * max / s, info.size.height * max / s)
            }
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > max * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return ctx.contentResolver.openInputStream(uri)!!.use {
            BitmapFactory.decodeStream(it, null, opts)!!
        }
    }
}
