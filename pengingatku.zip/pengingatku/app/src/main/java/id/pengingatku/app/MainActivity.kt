package id.pengingatku.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.result.contract.ActivityResultContracts
import id.pengingatku.app.notify.NotificationScheduler
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import id.pengingatku.app.model.Reminder
import id.pengingatku.app.ui.*
import id.pengingatku.app.ui.theme.PengingatkuTheme
import id.pengingatku.app.widget.WidgetUpdater
import kotlinx.coroutines.delay
import java.time.LocalDateTime

const val EXTRA_REMINDER_ID = "reminder_id"

class MainActivity : ComponentActivity() {
    private var openId by mutableStateOf<Long?>(null)
    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        openId = idFrom(intent)
        WidgetUpdater.refreshAsync(this)
        NotificationScheduler.rescheduleAll(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { PengingatkuApp(openId) { openId = null } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        openId = idFrom(intent)
    }

    private fun idFrom(i: Intent?): Long? =
        i?.getLongExtra(EXTRA_REMINDER_ID, -1L)?.takeIf { it >= 0 }
}

private val TABS = listOf("Beranda" to "🏠", "Kalender" to "🗓", "Pengingat" to "🔔", "Pengaturan" to "⚙️")

@Composable
fun PengingatkuApp(openId: Long?, onOpenConsumed: () -> Unit) {
    val ctx = LocalContext.current
    val state = remember { AppState(ctx) }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) { delay(30_000); now = LocalDateTime.now() }
    }
    val dark = when (state.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    PengingatkuTheme(dark, state.dynamicColor) {
        var tab by rememberSaveable { mutableIntStateOf(0) }
        var detailId by remember { mutableStateOf<Long?>(null) }
        var editing by remember { mutableStateOf(false) }
        var editTarget by remember { mutableStateOf<Reminder?>(null) }

        LaunchedEffect(openId) {
            if (openId != null) {
                if (state.reminders.any { it.id == openId }) detailId = openId
                onOpenConsumed()
            }
        }

        BackHandler(enabled = editing || detailId != null) {
            if (editing) editing = false else detailId = null
        }

        Box(Modifier.fillMaxSize().background(appBrush())) {
            Scaffold(
                containerColor = Color.Transparent,
                contentColor = MaterialTheme.colorScheme.onBackground,
                bottomBar = {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f)) {
                        TABS.forEachIndexed { i, (label, icon) ->
                            NavigationBarItem(
                                selected = tab == i, onClick = { tab = i },
                                icon = { Text(icon) }, label = { Text(label) }
                            )
                        }
                    }
                },
                floatingActionButton = {
                    if (tab == 0 || tab == 2) {
                        ExtendedFloatingActionButton(
                            onClick = { editTarget = null; editing = true },
                            icon = { Text("＋") },
                            text = { Text("Tambah Pengingat") }
                        )
                    }
                }
            ) { pad ->
                when (tab) {
                    0 -> HomeScreen(state, now, pad) { detailId = it }
                    1 -> CalendarScreen(state, now, pad) { detailId = it }
                    2 -> RemindersScreen(state, now, pad) { detailId = it }
                    else -> SettingsScreen(state, pad)
                }
            }

            detailId?.let { id ->
                state.reminders.find { it.id == id }?.let { r ->
                    DetailScreen(
                        r, now,
                        onBack = { detailId = null },
                        onEdit = { editTarget = r; editing = true },
                        onDelete = { state.remove(id); detailId = null },
                        onPin = { state.togglePin(id) }
                    )
                }
            }

            if (editing) {
                EditScreen(
                    initial = editTarget,
                    onSave = { state.upsert(it); editing = false },
                    onClose = { editing = false }
                )
            }
        }
    }
}
