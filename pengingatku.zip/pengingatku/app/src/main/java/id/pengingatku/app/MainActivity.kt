package id.pengingatku.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import id.pengingatku.app.model.Reminder
import id.pengingatku.app.ui.*
import id.pengingatku.app.ui.theme.PengingatkuTheme
import kotlinx.coroutines.delay
import java.time.LocalDateTime

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { PengingatkuApp() }
    }
}

private val TABS = listOf("Beranda" to "🏠", "Kalender" to "🗓", "Pengingat" to "🔔", "Pengaturan" to "⚙️")

@Composable
fun PengingatkuApp() {
    val state = remember { AppState() }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) { delay(30_000); now = LocalDateTime.now() }
    }
    val dark = when (state.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    PengingatkuTheme(dark, state.dynamicColor) {
        var tab by rememberSaveable { mutableIntStateOf(0) }
        var detailId by remember { mutableStateOf<Long?>(null) }
        var editing by remember { mutableStateOf(false) }
        var editTarget by remember { mutableStateOf<Reminder?>(null) }

        BackHandler(enabled = editing || detailId != null) {
            if (editing) editing = false else detailId = null
        }

        Box(Modifier.fillMaxSize()) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    NavigationBar {
                        TABS.forEachIndexed { i, (label, icon) ->
                            NavigationBarItem(
                                selected = tab == i, onClick = { tab = i },
                                icon = { Text(icon) }, label = { Text(label) }
                            )
                        }
                    }
                },
                floatingActionButton = {
                    if (tab == 0 || tab == 2) {
                        ExtendedFloatingActionButton(
                            onClick = { editTarget = null; editing = true },
                            icon = { Text("＋") },
                            text = { Text("Tambah Pengingat") }
                        )
                    }
                }
            ) { pad ->
                when (tab) {
                    0 -> HomeScreen(state, now, pad) { detailId = it }
                    1 -> CalendarScreen(state, now, pad) { detailId = it }
                    2 -> RemindersScreen(state, now, pad) { detailId = it }
                    else -> SettingsScreen(state, pad)
                }
            }

            detailId?.let { id ->
                state.reminders.find { it.id == id }?.let { r ->
                    DetailScreen(
                        r, now,
                        onBack = { detailId = null },
                        onEdit = { editTarget = r; editing = true },
                        onDelete = { state.remove(id); detailId = null },
                        onPin = { state.togglePin(id) }
                    )
                }
            }

            if (editing) {
                EditScreen(
                    initial = editTarget,
                    onSave = { state.upsert(it); editing = false },
                    onClose = { editing = false }
                )
            }
        }
    }
}
