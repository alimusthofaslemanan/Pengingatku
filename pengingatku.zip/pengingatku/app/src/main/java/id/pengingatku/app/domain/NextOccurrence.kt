package id.pengingatku.app.domain

import id.pengingatku.app.model.Recurrence
import id.pengingatku.app.model.Reminder
import id.pengingatku.app.model.dayBit
import id.pengingatku.app.model.effectiveMask
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.YearMonth
import java.time.temporal.ChronoUnit

object NextOccurrence {

    /** Occurrence berikutnya (belum lewat), atau null bila sekali & sudah lewat / diarsipkan. */
    fun of(r: Reminder, now: LocalDateTime): LocalDateTime? {
        if (r.archived) return null
        val start = r.date
        val today = now.toLocalDate()
        fun stamp(d: LocalDate) = if (r.allDay) d.atStartOfDay() else d.atTime(r.time)
        fun alive(d: LocalDate) =
            !(if (r.allDay) d.atTime(LocalTime.MAX) else d.atTime(r.time)).isBefore(now)

        if (r.recurrence == Recurrence.ONCE) return if (alive(start)) stamp(start) else null

        val from = if (today.isAfter(start)) today else start
        val n = r.interval.coerceAtLeast(1)
        val limit = when (r.recurrence) {
            Recurrence.DAILY -> n + 1
            Recurrence.WEEKLY -> 7 * n + 8
            Recurrence.MONTHLY, Recurrence.MONTHLY_NTH -> 31 * n + 62
            else -> 366 * n + 400
        }
        for (i in 0..limit) {
            val d = from.plusDays(i.toLong())
            if (matches(r, d) && alive(d)) return stamp(d)
        }
        return null
    }

    /** Apakah peristiwa jatuh pada tanggal tertentu (untuk kalender). */
    fun occursOn(r: Reminder, d: LocalDate): Boolean = !r.archived && matches(r, d)

    private fun matches(r: Reminder, d: LocalDate): Boolean {
        val s = r.date
        if (d.isBefore(s)) return false
        val n = r.interval.coerceAtLeast(1)
        val monthIdx = (d.year - s.year) * 12 + (d.monthValue - s.monthValue)
        val lastDay = YearMonth.from(d).lengthOfMonth()
        return when (r.recurrence) {
            Recurrence.ONCE -> d == s
            Recurrence.DAILY -> ChronoUnit.DAYS.between(s, d) % n == 0L
            Recurrence.WEEKLY -> {
                fun monday(x: LocalDate) = x.minusDays((x.dayOfWeek.value - 1).toLong())
                ChronoUnit.WEEKS.between(monday(s), monday(d)) % n == 0L &&
                    (r.effectiveMask() and dayBit(d.dayOfWeek)) != 0
            }
            // 29 Feb / tanggal 31 jatuh ke hari terakhir bulan bila bulan itu lebih pendek.
            Recurrence.MONTHLY ->
                monthIdx % n == 0 && d.dayOfMonth == minOf(s.dayOfMonth, lastDay)
            Recurrence.YEARLY ->
                (d.year - s.year) % n == 0 && d.month == s.month &&
                    d.dayOfMonth == minOf(s.dayOfMonth, lastDay)
            Recurrence.MONTHLY_NTH -> {
                val w = (s.dayOfMonth - 1) / 7 + 1
                val dw = (d.dayOfMonth - 1) / 7 + 1
                monthIdx % n == 0 && d.dayOfWeek == s.dayOfWeek &&
                    (if (w >= 5) d.plusDays(7).monthValue != d.monthValue else dw == w)
            }
        }
    }
}

val MONTHS = listOf(
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember"
)

fun LocalDate.idLong() = "$dayOfMonth ${MONTHS[monthValue - 1]} $year"
fun LocalDate.idShort() = "$dayOfMonth ${MONTHS[monthValue - 1]}"

fun countdownText(next: LocalDateTime?, now: LocalDateTime): String {
    if (next == null) return "Sudah lewat"
    val days = ChronoUnit.DAYS.between(now.toLocalDate(), next.toLocalDate())
    return when {
        days <= 0L -> {
            val m = ChronoUnit.MINUTES.between(now, next)
            when {
                m <= 0 -> "Hari ini ❤️"
                m >= 60 -> "${m / 60} jam ${m % 60} menit lagi"
                else -> "$m menit lagi"
            }
        }
        days == 1L -> "Besok"
        else -> "$days hari lagi"
    }
}
