package id.pengingatku.app.domain

import id.pengingatku.app.model.Recurrence
import id.pengingatku.app.model.Reminder
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.YearMonth
import java.time.temporal.ChronoUnit

object NextOccurrence {

    /** Occurrence berikutnya (>= now), atau null jika peristiwa sekali sudah lewat. */
    fun of(r: Reminder, now: LocalDateTime): LocalDateTime? {
        val start = r.date
        val today = now.toLocalDate()
        val from = if (today.isAfter(start)) today else start
        fun ok(d: LocalDate) = !d.isBefore(start) && !d.atTime(r.time).isBefore(now)

        return when (r.recurrence) {
            Recurrence.ONCE -> start.atTime(r.time).takeIf { !it.isBefore(now) }
            Recurrence.DAILY ->
                (0L..1L).map { from.plusDays(it) }.firstOrNull { ok(it) }?.atTime(r.time)
            Recurrence.WEEKLY ->
                (0L..7L).map { from.plusDays(it) }
                    .firstOrNull { it.dayOfWeek == start.dayOfWeek && ok(it) }?.atTime(r.time)
            Recurrence.MONTHLY -> {
                val base = YearMonth.from(from)
                (0L..13L).map { clamp(base.plusMonths(it), start.dayOfMonth) }
                    .firstOrNull { ok(it) }?.atTime(r.time)
            }
            Recurrence.YEARLY -> {
                (0..8).map { clamp(YearMonth.of(from.year + it, start.month), start.dayOfMonth) }
                    .firstOrNull { ok(it) }?.atTime(r.time)
            }
        }
    }

    /** Apakah peristiwa jatuh pada tanggal tertentu (untuk tampilan kalender). */
    fun occursOn(r: Reminder, d: LocalDate): Boolean {
        val s = r.date
        if (d.isBefore(s)) return false
        return when (r.recurrence) {
            Recurrence.ONCE -> d == s
            Recurrence.DAILY -> true
            Recurrence.WEEKLY -> d.dayOfWeek == s.dayOfWeek
            Recurrence.MONTHLY -> d == clamp(YearMonth.from(d), s.dayOfMonth)
            Recurrence.YEARLY -> d.month == s.month && d == clamp(YearMonth.from(d), s.dayOfMonth)
        }
    }

    // 29 Feb / tanggal 31 jatuh ke hari terakhir bulan bila bulan itu lebih pendek.
    private fun clamp(ym: YearMonth, day: Int): LocalDate =
        ym.atDay(minOf(day, ym.lengthOfMonth()))
}

val MONTHS = listOf(
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember"
)

fun LocalDate.idLong() = "$dayOfMonth ${MONTHS[monthValue - 1]} $year"
fun LocalDate.idShort() = "$dayOfMonth ${MONTHS[monthValue - 1]}"

fun countdownText(next: LocalDateTime?, now: LocalDateTime): String {
    if (next == null) return "Sudah lewat"
    val days = ChronoUnit.DAYS.between(now.toLocalDate(), next.toLocalDate())
    return when {
        days <= 0L -> {
            val m = ChronoUnit.MINUTES.between(now, next)
            when {
                m <= 0 -> "Hari ini ❤️"
                m >= 60 -> "${m / 60} jam ${m % 60} menit lagi"
                else -> "$m menit lagi"
            }
        }
        days == 1L -> "Besok"
        else -> "$days hari lagi"
    }
}
