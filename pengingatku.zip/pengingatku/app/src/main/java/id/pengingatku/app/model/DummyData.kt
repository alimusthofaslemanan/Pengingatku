package id.pengingatku.app.model

import java.time.LocalDate

object DummyData {
    fun all(): List<Reminder> = listOf(
        Reminder(1, "Ulang Tahun Naja", Category.BIRTHDAY, LocalDate.of(2020, 10, 8),
            recurrence = Recurrence.YEARLY, colorArgb = 0xFF4CAF7A, pinned = true,
            description = "Sehat, sholeh, dan selalu membahagiakan keluarga"),
        Reminder(2, "Hari Pernikahan", Category.WEDDING, LocalDate.of(2015, 10, 12),
            recurrence = Recurrence.YEARLY, colorArgb = 0xFFE91E63,
            description = "Semoga keluarga selalu sakinah, mawaddah, warahmah."),
        Reminder(3, "Pengajian Mingguan", Category.RELIGION, LocalDate.of(2026, 1, 4),
            recurrence = Recurrence.WEEKLY, colorArgb = 0xFF29A3D9,
            description = "Ilmu adalah cahaya hidup"),
        Reminder(4, "Bayar Listrik", Category.OTHER, LocalDate.of(2026, 1, 10),
            recurrence = Recurrence.MONTHLY, colorArgb = 0xFFFF9800),
        Reminder(5, "Minum Air", Category.OTHER, LocalDate.of(2026, 1, 1),
            recurrence = Recurrence.DAILY, colorArgb = 0xFF29A3D9)
    )
}
