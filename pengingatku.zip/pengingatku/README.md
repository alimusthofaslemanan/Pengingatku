# Pengingatku

Aplikasi Android (Kotlin, Jetpack Compose, Material 3) untuk pengingat peristiwa penting.

## Build lewat GitHub
1. Buat repositori baru, unggah seluruh isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** → workflow **Build APK** (jalan otomatis saat push, atau klik *Run workflow*).
3. Setelah hijau, unduh **pengingatku-debug-apk** dari bagian *Artifacts*, ekstrak, lalu pasang `app-debug.apk`.

## Status
- [x] Tahap 1: UI Compose + data dummy
- [x] Tahap 2 (sebagian): `NextOccurrence` (sekali/harian/mingguan/bulanan/tahunan, 29 Feb)
- [ ] Tahap 3: Room, foto, JSON backup
- [ ] Tahap 4: Widget Glance
- [ ] Tahap 5: Notifikasi
