# Pengingatku

Aplikasi Android (Kotlin, Jetpack Compose, Material 3) untuk pengingat peristiwa penting.

## Build lewat GitHub
1. Buat repositori baru, unggah seluruh isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** → workflow **Build APK** (jalan otomatis saat push, atau klik *Run workflow*).
3. Setelah hijau, unduh **pengingatku-debug-apk** dari bagian *Artifacts*, ekstrak, lalu pasang `app-debug.apk`.

## Status
- [x] Tahap 1: UI Compose + data dummy
- [x] Tahap 2 (sebagian): `NextOccurrence` (sekali/harian/mingguan/bulanan/tahunan, 29 Feb)
- [x] Penyimpanan lokal JSON (Room menyusul)
- [ ] Foto, backup JSON
- [x] Tahap 4 (sebagian): Widget Glance Peristiwa Terdekat (responsif kecil/sedang/besar)
- [ ] Tahap 5: Notifikasi
